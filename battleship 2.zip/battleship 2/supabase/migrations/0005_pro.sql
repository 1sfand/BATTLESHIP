-- ─── 0005_pro.sql ────────────────────────────────────────────────────────
-- Adds the `is_pro` flag and unlocks for premium tier (ADMIRAL'S PASS).

alter table public.profiles
  add column if not exists is_pro boolean not null default false,
  add column if not exists pro_expires_at timestamptz;

create index if not exists profiles_pro_idx
  on public.profiles (is_pro) where is_pro = true;
