-- ─── 0002_rls.sql ────────────────────────────────────────────────────────
-- Row Level Security: profiles read-public, games read-by-participant
-- (or public), story_progress read/write own only.

alter table public.profiles        enable row level security;
alter table public.games           enable row level security;
alter table public.story_progress  enable row level security;

-- ── profiles ─────────────────────────────────────────────────────────────
drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable"
  on public.profiles for select
  using (true);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- ── games ────────────────────────────────────────────────────────────────
drop policy if exists "Games visible to participants or if public" on public.games;
create policy "Games visible to participants or if public"
  on public.games for select
  using (
    is_public = true
    or auth.uid() = player1_id
    or auth.uid() = player2_id
  );

drop policy if exists "Users can insert their own games" on public.games;
create policy "Users can insert their own games"
  on public.games for insert
  with check (
    auth.uid() = player1_id or auth.uid() = player2_id
  );

drop policy if exists "Participants can update their game" on public.games;
create policy "Participants can update their game"
  on public.games for update
  using (auth.uid() = player1_id or auth.uid() = player2_id)
  with check (auth.uid() = player1_id or auth.uid() = player2_id);

-- ── story_progress ───────────────────────────────────────────────────────
drop policy if exists "Users can read their own progress" on public.story_progress;
create policy "Users can read their own progress"
  on public.story_progress for select
  using (auth.uid() = user_id);

drop policy if exists "Users can upsert their own progress" on public.story_progress;
create policy "Users can upsert their own progress"
  on public.story_progress for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own progress" on public.story_progress;
create policy "Users can update their own progress"
  on public.story_progress for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ── leaderboard view ─────────────────────────────────────────────────────
-- Views inherit RLS from underlying tables; profiles select policy is public.
grant select on public.leaderboard to anon, authenticated;
