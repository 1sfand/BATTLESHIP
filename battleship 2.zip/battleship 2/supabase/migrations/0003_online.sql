-- ─── 0003_online.sql ─────────────────────────────────────────────────────
-- Adds the schema needed for realtime online multiplayer.

create table if not exists public.online_rooms (
  id           uuid primary key default gen_random_uuid(),
  code         text not null unique check (char_length(code) = 6),
  host_id      uuid references public.profiles(id) on delete cascade,
  guest_id     uuid references public.profiles(id) on delete set null,
  -- 'lobby' | 'setup' | 'battle' | 'gameover'
  phase        text not null default 'lobby',
  -- Whose turn (0 = host, 1 = guest)
  turn         smallint default 0,
  -- Per-side ship placements once both submit
  host_state   jsonb,
  guest_state  jsonb,
  -- Append-only move log for sync + replay
  moves        jsonb not null default '[]'::jsonb,
  winner       smallint,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists online_rooms_code_idx on public.online_rooms (code);
create index if not exists online_rooms_host_idx on public.online_rooms (host_id);
create index if not exists online_rooms_guest_idx on public.online_rooms (guest_id);

alter table public.online_rooms enable row level security;

drop policy if exists "Rooms readable by participants" on public.online_rooms;
create policy "Rooms readable by participants"
  on public.online_rooms for select
  using (auth.uid() = host_id or auth.uid() = guest_id);

drop policy if exists "Host can insert their own room" on public.online_rooms;
create policy "Host can insert their own room"
  on public.online_rooms for insert
  with check (auth.uid() = host_id);

drop policy if exists "Participants can update room" on public.online_rooms;
create policy "Participants can update room"
  on public.online_rooms for update
  using (auth.uid() = host_id or auth.uid() = guest_id)
  with check (auth.uid() = host_id or auth.uid() = guest_id);

-- Enable realtime broadcast for this table
alter publication supabase_realtime add table public.online_rooms;
