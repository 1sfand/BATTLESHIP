-- ─── 0004_matchmaking.sql ────────────────────────────────────────────────
-- League-based quick-match queue. One row per user; we widen the search
-- window over time so isolated leagues still find opponents eventually.

create table if not exists public.matchmaking_queue (
  user_id     uuid primary key references public.profiles(id) on delete cascade,
  rating      int  not null,
  league      text not null,
  joined_at   timestamptz not null default now()
);

create index if not exists matchmaking_queue_league_idx
  on public.matchmaking_queue (league, rating);

alter table public.matchmaking_queue enable row level security;

drop policy if exists "Users can read their own queue entry" on public.matchmaking_queue;
create policy "Users can read their own queue entry"
  on public.matchmaking_queue for select
  using (auth.uid() = user_id);

drop policy if exists "Users can manage their own queue entry" on public.matchmaking_queue;
create policy "Users can manage their own queue entry"
  on public.matchmaking_queue for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ── helper: random 6-char room code (excludes confusing chars) ───────────
create or replace function public.gen_room_code()
returns text language plpgsql as $$
declare
  alphabet text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  result text := '';
  i int;
begin
  for i in 1..6 loop
    result := result || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
  end loop;
  return result;
end;
$$;

-- ── core matchmaker ──────────────────────────────────────────────────────
-- Returns the room id if a match is found (or already exists). Returns null
-- if we just got queued and the caller should poll.
create or replace function public.find_or_create_match()
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me_id      uuid := auth.uid();
  me_rating  int;
  me_league  text;
  opp        record;
  new_room   uuid;
  existing   uuid;
begin
  if me_id is null then
    raise exception 'not authenticated';
  end if;

  -- Already in a fresh room as a guest (someone just matched us)?
  select id into existing
    from public.online_rooms
   where (host_id = me_id or guest_id = me_id)
     and phase in ('lobby', 'setup')
     and created_at > now() - interval '15 seconds'
   order by created_at desc
   limit 1;
  if existing is not null then
    -- Clean up our queue entry just in case
    delete from public.matchmaking_queue where user_id = me_id;
    return existing;
  end if;

  -- Look up our rating + league
  select rating, case
    when rating >= 1800 then 'diamond'
    when rating >= 1600 then 'platinum'
    when rating >= 1400 then 'gold'
    when rating >= 1200 then 'silver'
    else 'bronze'
  end
  into me_rating, me_league
  from public.profiles
  where id = me_id;

  if me_rating is null then
    raise exception 'profile not found';
  end if;

  -- Try to find an opponent in our league
  select user_id, rating, joined_at
    into opp
    from public.matchmaking_queue
   where user_id <> me_id
     and league = me_league
   order by joined_at asc
   limit 1
   for update skip locked;

  if opp.user_id is not null then
    -- Match! Create a room with both of us, deleting both queue entries.
    insert into public.online_rooms (code, host_id, guest_id, phase)
    values (public.gen_room_code(), opp.user_id, me_id, 'setup')
    returning id into new_room;

    delete from public.matchmaking_queue where user_id in (me_id, opp.user_id);
    return new_room;
  end if;

  -- No opponent — queue ourselves and return null so caller polls
  insert into public.matchmaking_queue (user_id, rating, league)
  values (me_id, me_rating, me_league)
  on conflict (user_id) do update
    set rating    = excluded.rating,
        league    = excluded.league,
        joined_at = now();

  return null;
end;
$$;

grant execute on function public.find_or_create_match() to authenticated;

-- ── leave the queue (called when user navigates away) ────────────────────
create or replace function public.leave_matchmaking()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.matchmaking_queue where user_id = auth.uid();
end;
$$;

grant execute on function public.leave_matchmaking() to authenticated;
