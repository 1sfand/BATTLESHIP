-- ─── 0001_init.sql ───────────────────────────────────────────────────────
-- Run this in the Supabase SQL editor (or via `supabase db push`) once.

-- ── profiles ─────────────────────────────────────────────────────────────
-- Linked 1:1 with auth.users. Row created automatically on signup via trigger.

create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  nickname     text not null check (char_length(nickname) between 2 and 24),
  avatar_url   text,
  rating       int  not null default 1200,
  wins         int  not null default 0,
  losses       int  not null default 0,
  shots        int  not null default 0,
  hits         int  not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists profiles_rating_idx on public.profiles (rating desc);

-- Auto-bootstrap profile on signup with a generated nickname.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  generated_name text;
begin
  -- e.g. "Admiral-7Q3X" — collision-resistant enough at our scale
  generated_name := 'Admiral-' || upper(substr(replace(new.id::text, '-', ''), 1, 4));
  insert into public.profiles (id, nickname)
  values (new.id, generated_name)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ── games ────────────────────────────────────────────────────────────────
-- Append-only record of every finished game. moves[] enables replay viewer.

create table if not exists public.games (
  id                uuid primary key default gen_random_uuid(),
  mode              text not null check (mode in ('bot', 'local', 'online', 'story')),
  difficulty        text check (difficulty in ('easy', 'medium', 'hard')),
  story_chapter     int,
  player1_id        uuid references public.profiles(id) on delete set null,
  player2_id        uuid references public.profiles(id) on delete set null,
  winner_id         uuid references public.profiles(id) on delete set null,
  -- Snapshot stats at end of game
  player1_stats     jsonb not null default '{}'::jsonb,
  player2_stats     jsonb not null default '{}'::jsonb,
  -- Initial ship placements (so replay can render from scratch)
  initial_state     jsonb not null,
  -- Append-only move log: [{type, attacker, row, col, hit, sunkShipId, ts}, ...]
  moves             jsonb not null default '[]'::jsonb,
  -- Cached AI advisor commentary keyed by move index
  advisor_commentary jsonb,
  duration_seconds  int,
  created_at        timestamptz not null default now(),
  ended_at          timestamptz,
  -- Public games are visible in /replay, private only to participants
  is_public         boolean not null default true
);

create index if not exists games_player1_idx on public.games (player1_id, created_at desc);
create index if not exists games_player2_idx on public.games (player2_id, created_at desc);
create index if not exists games_public_idx  on public.games (is_public, created_at desc) where is_public;

-- ── story_progress ───────────────────────────────────────────────────────

create table if not exists public.story_progress (
  user_id              uuid primary key references public.profiles(id) on delete cascade,
  current_chapter      int not null default 1,
  completed_chapters   int[] not null default '{}',
  -- e.g. {"themes": ["naval"], "cosmetics": ["gold-pin"]}
  unlocks              jsonb not null default '{}'::jsonb,
  updated_at           timestamptz not null default now()
);

-- ── ELO update helper (called from server actions) ───────────────────────

create or replace function public.apply_elo(
  p_winner_id uuid,
  p_loser_id  uuid,
  p_k         int default 32
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  w_rating int;
  l_rating int;
  expected_w numeric;
  delta int;
begin
  select rating into w_rating from public.profiles where id = p_winner_id;
  select rating into l_rating from public.profiles where id = p_loser_id;
  if w_rating is null or l_rating is null then return; end if;

  expected_w := 1.0 / (1.0 + power(10, (l_rating - w_rating) / 400.0));
  delta := round(p_k * (1 - expected_w));

  update public.profiles
     set rating = rating + delta, wins = wins + 1, updated_at = now()
   where id = p_winner_id;
  update public.profiles
     set rating = greatest(0, rating - delta), losses = losses + 1, updated_at = now()
   where id = p_loser_id;
end;
$$;

-- ── public leaderboard view ──────────────────────────────────────────────

create or replace view public.leaderboard as
select id, nickname, avatar_url, rating, wins, losses,
       case when (wins + losses) > 0
            then round(100.0 * wins / (wins + losses))::int
            else 0 end as win_pct
from public.profiles
order by rating desc
limit 100;
