"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { SkinId } from "@/lib/skins/skins";

const FREE: SkinId[] = ["default"];

interface SkinStore {
  skin: SkinId;
  unlocked: SkinId[];
  setSkin: (skin: SkinId) => void;
  unlock: (skin: SkinId) => void;
  isUnlocked: (skin: SkinId) => boolean;
}

export const useSkinStore = create<SkinStore>()(
  persist(
    (set, get) => ({
      skin: "default",
      unlocked: [...FREE],
      setSkin: (skin) => {
        if (get().isUnlocked(skin)) set({ skin });
      },
      unlock: (skin) =>
        set((s) => (s.unlocked.includes(skin) ? s : { unlocked: [...s.unlocked, skin] })),
      isUnlocked: (skin) => FREE.includes(skin) || get().unlocked.includes(skin),
    }),
    { name: "battleship_skin_v1" },
  ),
);
