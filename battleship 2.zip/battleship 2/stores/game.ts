"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

import {
  BOARD_SIZE,
  SHIP_DEFS,
  createBoard,
  fireAt,
  getPositions,
  isFleetDestroyed,
  isValidPlacement,
  placeShipOnBoard,
  randomPlacement,
} from "@/lib/engine";
import type {
  BotMemory,
  Difficulty,
  GameMode,
  GameState,
  PlacedShip,
  PlayerState,
} from "@/lib/engine";
import {
  buildBotView,
  chooseBotShot,
  createBotMemory,
  updateBotMemory,
} from "@/lib/ai/bot";
import { uuid } from "@/lib/utils/cn";

// ─── Helpers ──────────────────────────────────────────────────────────────

function emptyPlayer(name: string): PlayerState {
  return { name, board: createBoard(), ships: [] };
}

function newGame(mode: GameMode, difficulty: Difficulty | null): GameState {
  return {
    id: uuid(),
    mode,
    difficulty,
    storyChapter: null,
    phase: "setup",
    players: [emptyPlayer("You"), emptyPlayer(mode === "bot" ? "Bot" : "Player 2")],
    stats: [
      { shots: 0, hits: 0 },
      { shots: 0, hits: 0 },
    ],
    setupPlayer: 0,
    placingIndex: 0,
    horizontal: true,
    battlePlayer: 0,
    passReason: null,
    lastShot: null,
    winner: null,
    startedAt: Date.now(),
    endedAt: null,
    moves: [],
  };
}

// ─── Store ────────────────────────────────────────────────────────────────

interface GameStore {
  game: GameState | null;
  botMemory: BotMemory | null;

  // ── Lifecycle ──
  startBotGame: (difficulty: Difficulty) => void;
  startLocalGame: () => void;
  reset: () => void;

  // ── Setup ──
  setOrientation: (horizontal: boolean) => void;
  toggleOrientation: () => void;
  placeAt: (row: number, col: number) => void;
  randomizeCurrentPlayer: () => void;
  confirmSetup: () => void;

  // ── Pass / phase transitions ──
  confirmPass: () => void;

  // ── Battle ──
  fireAtCell: (row: number, col: number) => void;
  runBotTurn: () => void;
}

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      game: null,
      botMemory: null,

      // ── Lifecycle ──
      startBotGame: (difficulty) => {
        const game = newGame("bot", difficulty);
        // Bot's fleet placed automatically
        const placement = randomPlacement();
        if (placement) {
          game.players[1] = {
            ...game.players[1],
            board: placement.board,
            ships: placement.ships,
          };
        }
        set({ game, botMemory: createBotMemory(difficulty) });
      },

      startLocalGame: () => {
        set({ game: newGame("local", null), botMemory: null });
      },

      reset: () => set({ game: null, botMemory: null }),

      // ── Setup ──
      setOrientation: (horizontal) =>
        set((s) => (s.game ? { game: { ...s.game, horizontal } } : s)),

      toggleOrientation: () =>
        set((s) =>
          s.game ? { game: { ...s.game, horizontal: !s.game.horizontal } } : s,
        ),

      placeAt: (row, col) => {
        const { game } = get();
        if (!game || game.phase !== "setup") return;
        if (game.placingIndex >= SHIP_DEFS.length) return;

        const def = SHIP_DEFS[game.placingIndex];
        const positions = getPositions(row, col, def.size, game.horizontal);
        const player = game.players[game.setupPlayer];
        if (!isValidPlacement(player.board, positions)) return;

        const newBoard = placeShipOnBoard(player.board, def.id, positions);
        const newShip: PlacedShip = {
          id: def.id,
          name: def.name,
          size: def.size,
          positions,
          sunk: false,
        };

        const players = [...game.players] as [PlayerState, PlayerState];
        players[game.setupPlayer] = {
          ...player,
          board: newBoard,
          ships: [...player.ships, newShip],
        };

        set({
          game: {
            ...game,
            players,
            placingIndex: game.placingIndex + 1,
          },
        });
      },

      randomizeCurrentPlayer: () => {
        const { game } = get();
        if (!game || game.phase !== "setup") return;

        let placement = randomPlacement();
        for (let i = 0; i < 10 && !placement; i++) placement = randomPlacement();
        if (!placement) return;

        const players = [...game.players] as [PlayerState, PlayerState];
        players[game.setupPlayer] = {
          ...players[game.setupPlayer],
          board: placement.board,
          ships: placement.ships,
        };

        set({
          game: {
            ...game,
            players,
            placingIndex: SHIP_DEFS.length,
          },
        });
      },

      confirmSetup: () => {
        const { game } = get();
        if (!game) return;

        if (game.mode === "bot") {
          // Player 1 (you) done; bot already placed → straight to battle
          set({
            game: {
              ...game,
              phase: "pass",
              battlePlayer: 0,
              passReason: "battle-start",
            },
          });
          return;
        }

        // Local 2-player
        if (game.setupPlayer === 0) {
          set({
            game: {
              ...game,
              phase: "pass",
              setupPlayer: 1,
              placingIndex: 0,
              passReason: "setup-done",
            },
          });
        } else {
          set({
            game: {
              ...game,
              phase: "pass",
              battlePlayer: 0,
              passReason: "battle-start",
            },
          });
        }
      },

      confirmPass: () => {
        const { game } = get();
        if (!game) return;

        if (game.passReason === "setup-done") {
          set({ game: { ...game, phase: "setup", passReason: null } });
        } else {
          set({
            game: {
              ...game,
              phase: "battle",
              passReason: null,
              lastShot: null,
            },
          });
        }
      },

      fireAtCell: (row, col) => {
        const { game, botMemory } = get();
        if (!game || game.phase !== "battle") return;

        const attackerIdx = game.battlePlayer;
        const defenderIdx = (attackerIdx ^ 1) as 0 | 1;
        const defender = game.players[defenderIdx];

        const result = fireAt(defender.board, defender.ships, row, col);
        if (!result) return;

        const players = [...game.players] as [PlayerState, PlayerState];
        players[defenderIdx] = {
          ...defender,
          board: result.board,
          ships: result.ships,
        };

        const stats = [...game.stats] as GameState["stats"];
        stats[attackerIdx] = {
          shots: stats[attackerIdx].shots + 1,
          hits: stats[attackerIdx].hits + (result.hit ? 1 : 0),
        };

        const moves = [
          ...game.moves,
          {
            type: "shot" as const,
            attacker: attackerIdx,
            row,
            col,
            hit: result.hit,
            sunkShipId: result.sunkShip?.id ?? null,
            ts: Date.now(),
          },
        ];

        const lastShot = {
          hit: result.hit,
          sunkShipName: result.sunkShip?.name ?? null,
        };

        // Game over?
        if (isFleetDestroyed(result.ships)) {
          set({
            game: {
              ...game,
              players,
              stats,
              moves,
              lastShot,
              phase: "gameover",
              winner: attackerIdx,
              endedAt: Date.now(),
            },
          });
          return;
        }

        // For bot mode: don't show pass screen — just chain the bot turn after
        // a short visual delay (handled in component layer).
        if (game.mode === "bot") {
          set({
            game: {
              ...game,
              players,
              stats,
              moves,
              lastShot,
              battlePlayer: defenderIdx,
              // stay in "battle" phase; component will trigger runBotTurn
            },
          });
          return;
        }

        // Local hot-seat: pass screen between turns
        set({
          game: {
            ...game,
            players,
            stats,
            moves,
            lastShot,
            phase: "pass",
            battlePlayer: defenderIdx,
            passReason: "battle-switch",
          },
        });

        // Bot memory updates only when bot was the attacker (not relevant here
        // since attacker was human in this branch, but kept for completeness).
        void botMemory;
      },

      runBotTurn: () => {
        const { game, botMemory } = get();
        if (!game || game.mode !== "bot" || game.phase !== "battle") return;
        if (game.battlePlayer !== 1 || !botMemory) return;

        const human = game.players[0];
        const view = buildBotView(human.board, human.ships);
        const [row, col] = chooseBotShot(view, botMemory);

        const result = fireAt(human.board, human.ships, row, col);
        if (!result) return;

        // Update bot memory with shot outcome
        updateBotMemory(
          botMemory,
          [row, col],
          result.hit,
          result.sunkShip !== null,
        );

        const players = [...game.players] as [PlayerState, PlayerState];
        players[0] = { ...human, board: result.board, ships: result.ships };

        const stats = [...game.stats] as GameState["stats"];
        stats[1] = {
          shots: stats[1].shots + 1,
          hits: stats[1].hits + (result.hit ? 1 : 0),
        };

        const moves = [
          ...game.moves,
          {
            type: "shot" as const,
            attacker: 1 as const,
            row,
            col,
            hit: result.hit,
            sunkShipId: result.sunkShip?.id ?? null,
            ts: Date.now(),
          },
        ];

        const lastShot = {
          hit: result.hit,
          sunkShipName: result.sunkShip?.name ?? null,
        };

        if (isFleetDestroyed(result.ships)) {
          set({
            game: {
              ...game,
              players,
              stats,
              moves,
              lastShot,
              phase: "gameover",
              winner: 1,
              endedAt: Date.now(),
            },
            botMemory: { ...botMemory },
          });
          return;
        }

        set({
          game: {
            ...game,
            players,
            stats,
            moves,
            lastShot,
            battlePlayer: 0,
          },
          botMemory: { ...botMemory },
        });
      },
    }),
    {
      name: "battleship_game_v1",
      storage: createJSONStorage(() => localStorage),
      // Don't persist botMemory shape changes incompatibly
      partialize: (s) => ({ game: s.game, botMemory: s.botMemory }),
    },
  ),
);

export const BOARD_DIM = BOARD_SIZE;
