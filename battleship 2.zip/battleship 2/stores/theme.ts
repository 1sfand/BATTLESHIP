"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

/**
 * Free themes: dark, light.
 * Locked themes: naval, neon, retro, paper — must be unlocked via story or paid.
 */
export type ThemeId = "dark" | "light" | "naval" | "neon" | "retro" | "paper";

const FREE_THEMES: ThemeId[] = ["dark", "light"];

interface ThemeStore {
  theme: ThemeId;
  unlocked: ThemeId[];
  setTheme: (theme: ThemeId) => void;
  unlock: (theme: ThemeId) => void;
  isUnlocked: (theme: ThemeId) => boolean;
}

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set, get) => ({
      theme: "dark",
      unlocked: [...FREE_THEMES],
      setTheme: (theme) => {
        if (get().isUnlocked(theme)) set({ theme });
      },
      unlock: (theme) =>
        set((s) =>
          s.unlocked.includes(theme) ? s : { unlocked: [...s.unlocked, theme] },
        ),
      isUnlocked: (theme) =>
        FREE_THEMES.includes(theme) || get().unlocked.includes(theme),
    }),
    { name: "battleship_theme_v1" },
  ),
);
