import type { Difficulty, ShipId } from "@/lib/engine";
import type { ThemeId } from "@/stores/theme";

/**
 * Story chapters are data-driven so adding new ones is trivial: append a new
 * entry. Each chapter defines a fixed opponent fleet (preset placements), a
 * difficulty, dialogue lines, and a reward (theme/cosmetic unlock).
 */

export interface ChapterDialogue {
  who: "admiral" | "narrator" | "you";
  text: string;
}

export interface ChapterReward {
  type: "theme" | "cosmetic";
  id: ThemeId | string;
  label: string;
}

export interface PresetShip {
  id: ShipId;
  positions: [number, number][];
}

export interface Chapter {
  id: number;
  title: string;
  admiral: string;          // opponent admiral name
  portrait: string;         // emoji or path; emoji for now
  intro: ChapterDialogue[];
  outroWin: ChapterDialogue[];
  outroLose: ChapterDialogue[];
  difficulty: Difficulty;
  /** Optional: pre-placed enemy fleet. If omitted, randomized. */
  preset?: PresetShip[];
  reward: ChapterReward | null;
  /** Special-rule hooks for future use (radar, no-touching strict, etc). */
  rules?: { firstShotFreeReveal?: boolean };
}

export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    title: "The Recruit",
    admiral: "Lt. Volkov",
    portrait: "🧑‍✈️",
    intro: [
      { who: "narrator", text: "Sea trials, dawn. The fleet eyes your every move." },
      { who: "admiral", text: "Sink my ships and I'll let you out of the bay. Easy enough, recruit?" },
    ],
    outroWin: [
      { who: "admiral", text: "Adequate. The harbor is yours — for now." },
    ],
    outroLose: [
      { who: "admiral", text: "Back to the galley. Try again when you can find a ship." },
    ],
    difficulty: "easy",
    reward: { type: "cosmetic", id: "rookie-pin", label: "🎖 Rookie Pin" },
  },
  {
    id: 2,
    title: "The Strait",
    admiral: "Cmdr. Hale",
    portrait: "🧔",
    intro: [
      { who: "narrator", text: "A narrow passage. Visibility limited. Hale doesn't miss." },
      { who: "admiral", text: "I've been hunting longer than you've been alive. Don't waste a shot." },
    ],
    outroWin: [
      { who: "admiral", text: "Hm. Not the worst I've seen. The strait is clear." },
    ],
    outroLose: [
      { who: "admiral", text: "Another wreck for the reef. Better luck next tide." },
    ],
    difficulty: "medium",
    reward: { type: "theme", id: "naval", label: "🎨 Naval theme" },
  },
  {
    id: 3,
    title: "The Admiral",
    admiral: "Adm. Kestrel",
    portrait: "🧙",
    intro: [
      { who: "narrator", text: "Open ocean. Storm on the horizon. Kestrel is legend." },
      { who: "admiral", text: "I have read every shot you've ever fired. Surrender, captain." },
      { who: "you", text: "Not today, admiral." },
    ],
    outroWin: [
      { who: "admiral", text: "The board… you saw the board. Bravo, captain. Bravo." },
    ],
    outroLose: [
      { who: "admiral", text: "As the tide foretold. Sail well — when you can sail at all." },
    ],
    difficulty: "hard",
    reward: { type: "theme", id: "neon", label: "✨ Neon theme" },
  },
];

export function getChapter(id: number): Chapter | null {
  return CHAPTERS.find((c) => c.id === id) ?? null;
}
