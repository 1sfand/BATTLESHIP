"use client";

import { createBrowserClient } from "@supabase/ssr";
import { getSupabaseEnv } from "./env";

let cached: ReturnType<typeof createBrowserClient> | null = null;

/**
 * Browser-side Supabase client. Returns `null` if env vars are missing —
 * components must handle that case gracefully (e.g. show offline banner).
 *
 * Untyped client (Database generic omitted) so we can move fast; cast results
 * to row types from `./types` at use-site.
 */
export function getSupabaseBrowser() {
  if (cached) return cached;
  const env = getSupabaseEnv();
  if (!env) return null;
  cached = createBrowserClient(env.url, env.anonKey);
  return cached;
}
