/**
 * Hand-written DB types. Replace with `supabase gen types typescript` output
 * once we have a CLI link to the project.
 */
import type { GameMode, Difficulty } from "@/lib/engine";

export interface ProfileRow {
  id: string;
  nickname: string;
  avatar_url: string | null;
  rating: number;
  wins: number;
  losses: number;
  shots: number;
  hits: number;
  created_at: string;
  updated_at: string;
}

export interface GameRow {
  id: string;
  mode: GameMode;
  difficulty: Difficulty | null;
  story_chapter: number | null;
  player1_id: string | null;
  player2_id: string | null;
  winner_id: string | null;
  player1_stats: Record<string, unknown>;
  player2_stats: Record<string, unknown>;
  initial_state: Record<string, unknown>;
  moves: unknown[];
  advisor_commentary: Record<string, unknown> | null;
  duration_seconds: number | null;
  created_at: string;
  ended_at: string | null;
  is_public: boolean;
}

export interface StoryProgressRow {
  user_id: string;
  current_chapter: number;
  completed_chapters: number[];
  unlocks: { themes?: string[]; cosmetics?: string[] };
  updated_at: string;
}

export interface LeaderboardRow {
  id: string;
  nickname: string;
  avatar_url: string | null;
  rating: number;
  wins: number;
  losses: number;
  win_pct: number;
}

export interface Database {
  public: {
    Tables: {
      profiles: { Row: ProfileRow; Insert: Partial<ProfileRow> & { id: string; nickname: string }; Update: Partial<ProfileRow> };
      games: { Row: GameRow; Insert: Partial<GameRow> & { mode: GameMode; initial_state: Record<string, unknown> }; Update: Partial<GameRow> };
      story_progress: { Row: StoryProgressRow; Insert: Partial<StoryProgressRow> & { user_id: string }; Update: Partial<StoryProgressRow> };
    };
    Views: {
      leaderboard: { Row: LeaderboardRow };
    };
  };
}
