import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { getSupabaseEnv } from "./env";

/**
 * Server-side Supabase client for Route Handlers, Server Components, and
 * Server Actions. Returns `null` if env vars are missing.
 *
 * Per Next.js 16 App Router conventions, `cookies()` is async.
 */
export async function getSupabaseServer() {
  const env = getSupabaseEnv();
  if (!env) return null;

  const cookieStore = await cookies();
  return createServerClient(env.url, env.anonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(toSet) {
        try {
          for (const { name, value, options } of toSet) {
            cookieStore.set(name, value, options);
          }
        } catch {
          // Called from a Server Component that can't write cookies — safe to ignore
          // since the middleware refreshes sessions for navigation requests.
        }
      },
    },
  });
}
