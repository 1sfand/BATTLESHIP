/**
 * Cosmetic ship skins. Each skin overrides how ship cells render — the icon
 * shown inside each ship cell is chosen by ship size.
 *
 * Showcase images are public-domain photographs from Wikimedia Commons,
 * served directly via Wikipedia's CDN (no hotlink restrictions, stable URLs).
 */

import type { ShipId } from "@/lib/engine";

export type SkinId =
  | "default"
  | "realistic"
  | "doner"
  | "coins"
  | "pirate";

export interface Skin {
  id: SkinId;
  name: string;
  blurb: string;
  /** True = locked behind Admiral's Pass. */
  pro: boolean;
  /** Wikipedia / Wikimedia Commons hero image. */
  showcase: string;
  /** Emoji rendered in each ship cell. null = no icon (just the color). */
  icons: Record<ShipId, string | null>;
  /** Tailwind class applied to ship cells (overrides bg-ship). */
  cellTone?: string;
}

export const SKINS: Skin[] = [
  {
    id: "default",
    name: "Default",
    blurb: "Classic blue squares. Clean and unambiguous.",
    pro: false,
    showcase:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/USS_Iowa_BB-61_firing.jpg/640px-USS_Iowa_BB-61_firing.jpg",
    icons: {
      carrier: null,
      battleship: null,
      cruiser: null,
      submarine: null,
      destroyer: null,
    },
  },
  {
    id: "realistic",
    name: "Real Ships",
    blurb: "Aircraft carrier, battleship, cruiser, submarine, destroyer — each shown with its actual silhouette.",
    pro: true,
    showcase:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/USS_Missouri_BB-63.jpg/640px-USS_Missouri_BB-63.jpg",
    icons: {
      carrier: "🛳️",
      battleship: "🚢",
      cruiser: "⛴️",
      submarine: "🤿",
      destroyer: "🚤",
    },
  },
  {
    id: "doner",
    name: "Döner Fleet",
    blurb: "A whole armada of meaty cylinders. Surprisingly intimidating.",
    pro: true,
    showcase:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Doner_kebab_HK_Sept_19_2016_lunch_dish.jpg/640px-Doner_kebab_HK_Sept_19_2016_lunch_dish.jpg",
    icons: {
      carrier: "🥙",
      battleship: "🌯",
      cruiser: "🌮",
      submarine: "🥪",
      destroyer: "🍖",
    },
  },
  {
    id: "coins",
    name: "Treasure Chest",
    blurb: "Trade ships hauling gold, gems, and bullion. Sink to plunder.",
    pro: true,
    showcase:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Pile_of_Golden_Coins.jpg/640px-Pile_of_Golden_Coins.jpg",
    icons: {
      carrier: "💰",
      battleship: "🪙",
      cruiser: "💎",
      submarine: "👑",
      destroyer: "🏆",
    },
  },
  {
    id: "pirate",
    name: "Black Flag",
    blurb: "Flying the Jolly Roger. Show no mercy, ask for none.",
    pro: true,
    showcase:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Pirate_Flag_of_Edward_England.svg/640px-Pirate_Flag_of_Edward_England.svg.png",
    icons: {
      carrier: "🏴‍☠️",
      battleship: "💀",
      cruiser: "⚔️",
      submarine: "🦴",
      destroyer: "🗡️",
    },
  },
];

export function getSkin(id: SkinId): Skin {
  return SKINS.find((s) => s.id === id) ?? SKINS[0];
}
