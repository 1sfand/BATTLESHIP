import type { ShipDef } from "./types";

export const BOARD_SIZE = 10;
export const COLS = "ABCDEFGHIJ";

export const SHIP_DEFS: readonly ShipDef[] = [
  { id: "carrier", name: "Carrier", size: 5 },
  { id: "battleship", name: "Battleship", size: 4 },
  { id: "cruiser", name: "Cruiser", size: 3 },
  { id: "submarine", name: "Submarine", size: 3 },
  { id: "destroyer", name: "Destroyer", size: 2 },
] as const;

export const TOTAL_SHIP_CELLS = SHIP_DEFS.reduce((s, d) => s + d.size, 0);
