import { BOARD_SIZE } from "./constants";
import type { Board, Position } from "./types";

export function createBoard(): Board {
  return Array.from({ length: BOARD_SIZE }, () =>
    Array.from({ length: BOARD_SIZE }, () => ({ shipId: null, hit: false })),
  );
}

export function inBounds(row: number, col: number): boolean {
  return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
}

export function cloneBoard(board: Board): Board {
  return board.map((row) => row.map((cell) => ({ ...cell })));
}

export function getPositions(
  row: number,
  col: number,
  size: number,
  horizontal: boolean,
): Position[] {
  return Array.from(
    { length: size },
    (_, i) => (horizontal ? [row, col + i] : [row + i, col]) as Position,
  );
}

/**
 * Returns a copy of the board with `shipId` stripped from every cell that
 * has not been hit yet. Use when rendering an opponent's board so React state
 * / devtools / accidental CSS rules cannot leak ship locations.
 */
export function censorBoard(board: Board): Board {
  return board.map((row) =>
    row.map((cell) =>
      cell.hit ? { ...cell } : { shipId: null, hit: false },
    ),
  );
}
