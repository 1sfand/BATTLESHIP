import { SHIP_DEFS } from "./constants";
import { cloneBoard, createBoard, getPositions, inBounds } from "./board";
import type { Board, PlacedShip, Position, ShipId } from "./types";

/**
 * Validates placement: in-bounds, no overlap, no adjacency (touching ships forbidden).
 */
export function isValidPlacement(board: Board, positions: Position[]): boolean {
  for (const [r, c] of positions) {
    if (!inBounds(r, c)) return false;
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        const nr = r + dr;
        const nc = c + dc;
        if (inBounds(nr, nc) && board[nr][nc].shipId !== null) return false;
      }
    }
  }
  return true;
}

export function placeShipOnBoard(
  board: Board,
  shipId: ShipId,
  positions: Position[],
): Board {
  const next = cloneBoard(board);
  for (const [r, c] of positions) next[r][c].shipId = shipId;
  return next;
}

/** Random valid placement of full fleet. Caller can retry on null. */
export function randomPlacement(): { board: Board; ships: PlacedShip[] } | null {
  let board = createBoard();
  const ships: PlacedShip[] = [];

  for (const def of SHIP_DEFS) {
    let placed = false;
    for (let attempts = 0; attempts < 500 && !placed; attempts++) {
      const horizontal = Math.random() < 0.5;
      const row = Math.floor(Math.random() * 10);
      const col = Math.floor(Math.random() * 10);
      const positions = getPositions(row, col, def.size, horizontal);
      if (isValidPlacement(board, positions)) {
        board = placeShipOnBoard(board, def.id, positions);
        ships.push({
          id: def.id,
          name: def.name,
          size: def.size,
          positions,
          sunk: false,
        });
        placed = true;
      }
    }
    if (!placed) return null;
  }

  return { board, ships };
}
