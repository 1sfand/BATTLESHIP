// ─── Core game types ──────────────────────────────────────────────────────

export type Orientation = "horizontal" | "vertical";

export interface ShipDef {
  id: ShipId;
  name: string;
  size: number;
}

export type ShipId = "carrier" | "battleship" | "cruiser" | "submarine" | "destroyer";

/** Position as [row, col]. Row 0 = top, col 0 = left. */
export type Position = readonly [number, number];

export interface Cell {
  shipId: ShipId | null;
  hit: boolean;
}

export type Board = Cell[][];

export interface PlacedShip {
  id: ShipId;
  name: string;
  size: number;
  positions: Position[];
  sunk: boolean;
}

export interface PlayerState {
  name: string;
  board: Board;
  ships: PlacedShip[];
}

// ─── Move log (for replay) ───────────────────────────────────────────────

export interface ShotMove {
  type: "shot";
  attacker: 0 | 1;
  row: number;
  col: number;
  hit: boolean;
  sunkShipId: ShipId | null;
  ts: number;
}

export type Move = ShotMove;

// ─── Game state ──────────────────────────────────────────────────────────

export type GamePhase =
  | "welcome"
  | "setup"
  | "pass"
  | "battle"
  | "gameover";

export type GameMode = "bot" | "local" | "online" | "story";
export type Difficulty = "easy" | "medium" | "hard";

export interface PlayerStats {
  shots: number;
  hits: number;
}

export interface GameState {
  id: string;                       // local UUID; persisted as game id when synced
  mode: GameMode;
  difficulty: Difficulty | null;
  storyChapter: number | null;
  phase: GamePhase;
  players: [PlayerState, PlayerState];
  stats: [PlayerStats, PlayerStats];

  // setup
  setupPlayer: 0 | 1;
  placingIndex: number;
  horizontal: boolean;

  // battle
  battlePlayer: 0 | 1;
  passReason: "setup-done" | "battle-start" | "battle-switch" | null;
  lastShot: { hit: boolean; sunkShipName: string | null } | null;

  // outcome
  winner: 0 | 1 | null;
  startedAt: number;
  endedAt: number | null;

  // replay log
  moves: Move[];
}

// ─── Bot AI memory ───────────────────────────────────────────────────────
// Stored per game so we can resume a saved bot game without losing state.

export interface BotMemory {
  difficulty: Difficulty;
  // For medium/hard: cells we've already targeted that aren't useful
  // For medium: queue of follow-up shots after a hit
  pendingTargets: Position[];
  // Last hits not yet attributed to a sunk ship — used to follow up
  activeHits: Position[];
  // Hard mode: cached probability map (rebuilt per turn, but useful for tests)
  lastHeatmapMax?: number;
}
