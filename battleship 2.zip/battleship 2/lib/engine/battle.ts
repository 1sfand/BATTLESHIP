import { cloneBoard } from "./board";
import type { Board, PlacedShip } from "./types";

export interface ShotResult {
  board: Board;
  ships: PlacedShip[];
  hit: boolean;
  sunkShip: PlacedShip | null;
}

/** Returns null if cell already shot, else the new board + ship state. */
export function fireAt(
  board: Board,
  ships: PlacedShip[],
  row: number,
  col: number,
): ShotResult | null {
  if (board[row][col].hit) return null;

  const nextBoard = cloneBoard(board);
  nextBoard[row][col].hit = true;

  const shipId = nextBoard[row][col].shipId;
  let sunkShip: PlacedShip | null = null;

  const nextShips = ships.map((s) => {
    if (s.id !== shipId) return s;
    const sunk = s.positions.every(([r, c]) => nextBoard[r][c].hit);
    if (sunk && !s.sunk) {
      const updated = { ...s, sunk: true };
      sunkShip = updated;
      return updated;
    }
    return s;
  });

  return { board: nextBoard, ships: nextShips, hit: shipId !== null, sunkShip };
}

export function isFleetDestroyed(ships: PlacedShip[]): boolean {
  return ships.every((s) => s.sunk);
}
