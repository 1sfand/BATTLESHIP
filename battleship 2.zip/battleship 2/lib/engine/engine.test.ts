/**
 * Smoke tests for the engine. Run with: bun test
 */
import { test, expect } from "bun:test";
import {
  BOARD_SIZE,
  SHIP_DEFS,
  TOTAL_SHIP_CELLS,
  createBoard,
  fireAt,
  getPositions,
  isFleetDestroyed,
  isValidPlacement,
  placeShipOnBoard,
  randomPlacement,
} from "./index";

test("createBoard makes 10×10 of empty cells", () => {
  const b = createBoard();
  expect(b).toHaveLength(BOARD_SIZE);
  expect(b[0]).toHaveLength(BOARD_SIZE);
  expect(b[5][5]).toEqual({ shipId: null, hit: false });
});

test("isValidPlacement rejects out-of-bounds", () => {
  const b = createBoard();
  expect(isValidPlacement(b, getPositions(0, 7, 5, true))).toBe(false);
});

test("isValidPlacement rejects adjacent ships", () => {
  let b = createBoard();
  b = placeShipOnBoard(b, "carrier", getPositions(0, 0, 5, true));
  // Adjacent placement (touching diagonally) should fail
  expect(isValidPlacement(b, getPositions(1, 0, 4, true))).toBe(false);
  // Far away should succeed
  expect(isValidPlacement(b, getPositions(2, 0, 4, true))).toBe(true);
});

test("fireAt records hit and detects sink", () => {
  const positions = getPositions(0, 0, 2, true);
  const board = placeShipOnBoard(createBoard(), "destroyer", positions);
  const ships = [
    {
      id: "destroyer" as const,
      name: "Destroyer",
      size: 2,
      positions,
      sunk: false,
    },
  ];

  const r1 = fireAt(board, ships, 0, 0)!;
  expect(r1.hit).toBe(true);
  expect(r1.sunkShip).toBe(null);

  const r2 = fireAt(r1.board, r1.ships, 0, 1)!;
  expect(r2.hit).toBe(true);
  expect(r2.sunkShip?.id).toBe("destroyer");
  expect(isFleetDestroyed(r2.ships)).toBe(true);
});

test("fireAt returns null on already-shot cell", () => {
  const board = createBoard();
  board[3][3].hit = true;
  expect(fireAt(board, [], 3, 3)).toBe(null);
});

test("randomPlacement produces a valid full fleet", () => {
  const result = randomPlacement();
  expect(result).not.toBeNull();
  if (!result) return;
  expect(result.ships).toHaveLength(SHIP_DEFS.length);
  // Total cells occupied
  let occupied = 0;
  for (const row of result.board) for (const c of row) if (c.shipId) occupied++;
  expect(occupied).toBe(TOTAL_SHIP_CELLS);
});
