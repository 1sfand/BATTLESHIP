/**
 * Competitive leagues derived from a player's ELO rating.
 * Thresholds chosen so a fresh account (1200) starts in Silver and progression
 * feels meaningful at every step.
 */

export type LeagueId = "bronze" | "silver" | "gold" | "platinum" | "diamond";

export interface League {
  id: LeagueId;
  name: string;
  /** Minimum ELO for this league (inclusive). */
  threshold: number;
  /** Tailwind classes used for the badge. */
  badge: string;
  /** Subtle accent color for league-themed UI. */
  accent: string;
  /** Symbol shown next to the name. */
  symbol: string;
  /** One-line lore. */
  motto: string;
}

export const LEAGUES: League[] = [
  {
    id: "diamond",
    name: "Diamond",
    threshold: 1800,
    badge: "bg-cyan-500/15 text-cyan-300 border-cyan-400/40",
    accent: "#22d3ee",
    symbol: "💠",
    motto: "Legendary admirals only.",
  },
  {
    id: "platinum",
    name: "Platinum",
    threshold: 1600,
    badge: "bg-sky-300/10 text-sky-200 border-sky-300/40",
    accent: "#bae6fd",
    symbol: "🔷",
    motto: "Veterans of the open sea.",
  },
  {
    id: "gold",
    name: "Gold",
    threshold: 1400,
    badge: "bg-amber-400/15 text-amber-300 border-amber-400/40",
    accent: "#facc15",
    symbol: "🥇",
    motto: "Skilled tacticians.",
  },
  {
    id: "silver",
    name: "Silver",
    threshold: 1200,
    badge: "bg-slate-300/15 text-slate-200 border-slate-300/40",
    accent: "#cbd5e1",
    symbol: "🥈",
    motto: "Solid seamanship.",
  },
  {
    id: "bronze",
    name: "Bronze",
    threshold: 0,
    badge: "bg-orange-500/15 text-orange-300 border-orange-500/40",
    accent: "#fb923c",
    symbol: "🥉",
    motto: "Just shipped.",
  },
];

export function getLeague(rating: number): League {
  // LEAGUES is sorted high→low so the first matching threshold wins
  return LEAGUES.find((l) => rating >= l.threshold) ?? LEAGUES[LEAGUES.length - 1];
}

export function nextLeague(rating: number): League | null {
  const current = getLeague(rating);
  const idx = LEAGUES.findIndex((l) => l.id === current.id);
  return idx > 0 ? LEAGUES[idx - 1] : null;
}

/** ELO required to reach the next league. Null if already Diamond. */
export function pointsToNextLeague(rating: number): number | null {
  const next = nextLeague(rating);
  return next ? Math.max(0, next.threshold - rating) : null;
}
