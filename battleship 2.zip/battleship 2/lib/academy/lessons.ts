export interface Lesson {
  id: string;
  title: string;
  category: "Strategy" | "Probability" | "History" | "Engineering";
  level: "Cadet" | "Officer" | "Captain" | "Admiral";
  emoji: string;
  /** Reading time, minutes. */
  minutes: number;
  /** True = part of the free preview. False = requires Admiral's Pass. */
  free: boolean;
  intro: string;
  /** Long-form body in plain text (newline-separated paragraphs). */
  body: string;
}

export const LESSONS: Lesson[] = [
  // ── FREE preview ──────────────────────────────────────────────────────
  {
    id: "fundamentals",
    title: "Fundamentals: hit, miss, sink",
    category: "Strategy",
    level: "Cadet",
    emoji: "⚓",
    minutes: 4,
    free: true,
    intro: "The three pieces of information every shot returns and what to do with each.",
    body: `Every shot in Battleship gives you one of three pieces of information.

A miss tells you that no ship occupies that exact cell. It does not — by itself — tell you anything about adjacent cells. But because ships are at least 2 cells long, a single miss eliminates more than just one square from your future search.

A hit tells you a ship is there, and dramatically narrows your search. The next shot you take should almost always be one of the four neighbours. Once you have two adjacent hits, you know the orientation, and the ship must extend along that line.

A sunk ship is the most valuable signal of all. It removes a known-size from the remaining ship pool, and it tells you that every cell adjacent to the sunk ship is empty (because ships cannot touch). Mark those cells off mentally — you will never need to shoot them.

The single biggest mistake new players make is to keep shooting around a hit even after the ship sinks. Always pause after a sink and ask: do I still have unfinished follow-ups, or should I switch to hunting fresh territory?`,
  },
  {
    id: "placement",
    title: "Placement: where ships actually hide",
    category: "Strategy",
    level: "Cadet",
    emoji: "🚢",
    minutes: 5,
    free: true,
    intro: "Edges, corners, and the no-touching rule rewrite which squares are safe.",
    body: `Beginners place ships in the middle of the board because the middle "feels safer." It is not. The middle has the most adjacent cells, so once a ship is hit, follow-up shots have more directions to expand into.

Edges and corners are statistically harder to hit because shots tend to cluster in the center, and because the no-touching rule means ships near the edge eat up less perimeter — so they're physically harder to detect via probability heatmaps.

But edges have a tradeoff: a ship placed flush against the edge has fewer adjacent cells, which means fewer cells to search once one of its squares is hit. Against a smart opponent, the edge is a double-edged sword.

A balanced placement strategy:
1. Hide your largest ship (Carrier, 5) in or near a corner.
2. Place your smallest ship (Destroyer, 2) in an unexpected place — they are hardest to find precisely because they are smallest.
3. Don't cluster all ships in one quadrant; spread them so no single hot zone reveals everything.
4. Vary horizontal/vertical orientation 50/50 — never all-horizontal.`,
  },

  // ── Locked: Admiral's Pass ───────────────────────────────────────────
  {
    id: "parity",
    title: "Parity: why the Hard bot uses a checkerboard",
    category: "Probability",
    level: "Officer",
    emoji: "♟",
    minutes: 6,
    free: false,
    intro: "The smallest ship is 2 cells, so half the board is provably skippable until first contact.",
    body: `Coming soon. (Locked content — Admiral's Pass required.)`,
  },
  {
    id: "heatmaps",
    title: "Probability density: the optimal opening",
    category: "Probability",
    level: "Officer",
    emoji: "🔥",
    minutes: 8,
    free: false,
    intro: "How to mentally compute which cell is statistically most likely to contain a ship.",
    body: `Coming soon.`,
  },
  {
    id: "endgame",
    title: "Endgame: hunting the last destroyer",
    category: "Strategy",
    level: "Captain",
    emoji: "🎯",
    minutes: 5,
    free: false,
    intro: "When only the smallest ship remains, your opening becomes irrelevant. Switch tactics.",
    body: `Coming soon.`,
  },
  {
    id: "history-jutland",
    title: "Jutland 1916: the original probabilistic battle",
    category: "History",
    level: "Captain",
    emoji: "📜",
    minutes: 9,
    free: false,
    intro: "Before computers, fleet commanders used grids and odds. Sound familiar?",
    body: `Coming soon.`,
  },
  {
    id: "history-midway",
    title: "Midway 1942: information asymmetry decides",
    category: "History",
    level: "Admiral",
    emoji: "🌊",
    minutes: 12,
    free: false,
    intro: "How knowing your opponent's ship placements (read: code-breaking) won the Pacific.",
    body: `Coming soon.`,
  },
  {
    id: "ship-engineering",
    title: "Why a Carrier is 5 and a Destroyer is 2",
    category: "Engineering",
    level: "Cadet",
    emoji: "📐",
    minutes: 4,
    free: false,
    intro: "The standard fleet sizes mirror real-world tonnage ratios.",
    body: `Coming soon.`,
  },
];

export function getLesson(id: string): Lesson | null {
  return LESSONS.find((l) => l.id === id) ?? null;
}
