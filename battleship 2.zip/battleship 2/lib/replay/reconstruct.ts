/**
 * Replay reconstruction: given saved initial_state + moves, deterministically
 * derive the board state at any move index. Pure function — no DOM.
 */
import { fireAt } from "@/lib/engine/battle";
import { createBoard } from "@/lib/engine/board";
import { placeShipOnBoard } from "@/lib/engine/placement";
import { SHIP_DEFS } from "@/lib/engine/constants";
import type { Board, PlacedShip, Move, ShipId, Position } from "@/lib/engine";

export interface ReplayInitial {
  p0_ships: { id: ShipId; positions: Position[] }[];
  p1_ships: { id: ShipId; positions: Position[] }[];
}

export interface ReplaySnapshot {
  boards: [Board, Board];
  ships: [PlacedShip[], PlacedShip[]];
  /** Index of the move that *just happened*, or -1 if start. */
  moveIndex: number;
  lastMove: Move | null;
}

function buildSide(side: ReplayInitial["p0_ships"]): {
  board: Board;
  ships: PlacedShip[];
} {
  let board = createBoard();
  const ships: PlacedShip[] = [];
  for (const s of side) {
    const def = SHIP_DEFS.find((d) => d.id === s.id);
    if (!def) continue;
    board = placeShipOnBoard(board, def.id, s.positions);
    ships.push({
      id: def.id,
      name: def.name,
      size: def.size,
      positions: s.positions,
      sunk: false,
    });
  }
  return { board, ships };
}

/** Returns initial snapshot (move -1) and a function for any later index. */
export function createReplay(initial: ReplayInitial, moves: Move[]) {
  const start0 = buildSide(initial.p0_ships);
  const start1 = buildSide(initial.p1_ships);

  function snapshotAt(targetIdx: number): ReplaySnapshot {
    let b0 = start0.board.map((r) => r.map((c) => ({ ...c })));
    let s0 = start0.ships.map((s) => ({ ...s, positions: [...s.positions] }));
    let b1 = start1.board.map((r) => r.map((c) => ({ ...c })));
    let s1 = start1.ships.map((s) => ({ ...s, positions: [...s.positions] }));

    let lastMove: Move | null = null;
    for (let i = 0; i <= targetIdx && i < moves.length; i++) {
      const m = moves[i];
      lastMove = m;
      if (m.type === "shot") {
        if (m.attacker === 0) {
          const r = fireAt(b1, s1, m.row, m.col);
          if (r) { b1 = r.board; s1 = r.ships; }
        } else {
          const r = fireAt(b0, s0, m.row, m.col);
          if (r) { b0 = r.board; s0 = r.ships; }
        }
      }
    }

    return {
      boards: [b0, b1],
      ships: [s0, s1],
      moveIndex: targetIdx,
      lastMove,
    };
  }

  return { snapshotAt, totalMoves: moves.length };
}
