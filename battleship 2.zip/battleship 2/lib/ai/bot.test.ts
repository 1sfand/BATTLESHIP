/**
 * Bot AI sanity tests — simulate full games to verify difficulty scaling.
 */
import { test, expect } from "bun:test";
import { randomPlacement, fireAt, isFleetDestroyed } from "@/lib/engine";
import {
  buildBotView,
  chooseBotShot,
  createBotMemory,
  updateBotMemory,
} from "./bot";
import type { Difficulty } from "@/lib/engine";

function simulateBotGame(difficulty: Difficulty): number {
  const placement = randomPlacement()!;
  let board = placement.board;
  let ships = placement.ships;
  const mem = createBotMemory(difficulty);
  let shots = 0;

  while (!isFleetDestroyed(ships) && shots < 100) {
    const view = buildBotView(board, ships);
    const [r, c] = chooseBotShot(view, mem);
    const result = fireAt(board, ships, r, c);
    if (!result) break;
    board = result.board;
    ships = result.ships;
    updateBotMemory(mem, [r, c], result.hit, result.sunkShip !== null);
    shots++;
  }

  return shots;
}

test("Easy bot finishes within 100 shots", () => {
  const shots = simulateBotGame("easy");
  expect(shots).toBeLessThanOrEqual(100);
  expect(shots).toBeGreaterThan(17); // must hit all 17 cells at least
});

test("Medium bot is meaningfully better than easy", () => {
  // Average over runs to smooth variance
  const N = 50;
  let easyTotal = 0;
  let medTotal = 0;
  for (let i = 0; i < N; i++) {
    easyTotal += simulateBotGame("easy");
    medTotal += simulateBotGame("medium");
  }
  const easyAvg = easyTotal / N;
  const medAvg = medTotal / N;
  // Medium should average noticeably fewer shots than easy
  expect(medAvg).toBeLessThan(easyAvg);
});

test("Hard bot is meaningfully better than medium", () => {
  const N = 50;
  let medTotal = 0;
  let hardTotal = 0;
  for (let i = 0; i < N; i++) {
    medTotal += simulateBotGame("medium");
    hardTotal += simulateBotGame("hard");
  }
  // Hard should average fewer shots than medium
  expect(hardTotal / N).toBeLessThan(medTotal / N);
});
