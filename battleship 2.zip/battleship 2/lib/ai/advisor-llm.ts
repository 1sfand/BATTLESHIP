/**
 * Advisor LLM abstraction. Supports any of these providers — first one with
 * a key set wins:
 *
 *  - Google Gemini (free, generous limits) — `GOOGLE_GENAI_API_KEY`
 *  - Anthropic Claude (paid)               — `ANTHROPIC_API_KEY`
 *
 * Returns an async iterable of text deltas, or throws if no provider configured.
 */
import { GoogleGenAI } from "@google/genai";
import Anthropic from "@anthropic-ai/sdk";

export interface AdvisorRequest {
  prompt: string;
  maxTokens?: number;
}

export interface AdvisorProvider {
  name: string;
  stream(req: AdvisorRequest): AsyncIterable<string>;
}

export function getAdvisorProvider(): AdvisorProvider | null {
  const gemini = process.env.GOOGLE_GENAI_API_KEY;
  if (gemini) return geminiProvider(gemini);

  const anthropic = process.env.ANTHROPIC_API_KEY;
  if (anthropic) return anthropicProvider(anthropic);

  return null;
}

function geminiProvider(apiKey: string): AdvisorProvider {
  const client = new GoogleGenAI({ apiKey });
  return {
    name: "gemini",
    async *stream({ prompt, maxTokens = 120 }) {
      const response = await client.models.generateContentStream({
        // 2.5-flash-lite has the most generous free-tier quota; bump to
        // gemini-2.5-flash if you upgrade for richer commentary.
        model: "gemini-2.5-flash-lite",
        contents: prompt,
        config: {
          maxOutputTokens: maxTokens,
          temperature: 0.8,
        },
      });
      for await (const chunk of response) {
        const text = chunk.text;
        if (text) yield text;
      }
    },
  };
}

function anthropicProvider(apiKey: string): AdvisorProvider {
  const client = new Anthropic({ apiKey });
  return {
    name: "anthropic",
    async *stream({ prompt, maxTokens = 120 }) {
      const response = await client.messages.stream({
        model: "claude-haiku-4-5-20251001",
        max_tokens: maxTokens,
        messages: [{ role: "user", content: prompt }],
      });
      for await (const chunk of response) {
        if (
          chunk.type === "content_block_delta" &&
          chunk.delta.type === "text_delta"
        ) {
          yield chunk.delta.text;
        }
      }
    },
  };
}
