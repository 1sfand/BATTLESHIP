import { BOARD_SIZE, SHIP_DEFS } from "../engine/constants";
import { inBounds } from "../engine/board";
import type {
  Board,
  BotMemory,
  Difficulty,
  PlacedShip,
  Position,
  ShipDef,
} from "../engine/types";

/**
 * Bot AI strategies. Each `chooseShot` is pure: takes current view of the
 * opponent's board (only `hit` flags are reliable; `shipId` is hidden from
 * the bot's perspective) plus persistent memory, returns the next target.
 *
 * The "view" board exposes only what the bot has observed:
 *   - cell.hit = true and cell.shipId set ⇒ bot scored a hit
 *   - cell.hit = true and cell.shipId null ⇒ miss
 *   - cell.hit = false ⇒ unknown
 *
 * The opponent's `ships` array is passed only so we know which ship sizes
 * remain (any ship with `sunk: true` removed from candidates). The bot does
 * NOT cheat — it only uses `sunk` info that is publicly announced.
 */

export interface BotView {
  board: Board;            // opponent's board from bot's POV
  remainingShipSizes: number[]; // sizes of opponent ships not yet sunk
}

export function createBotMemory(difficulty: Difficulty): BotMemory {
  return {
    difficulty,
    pendingTargets: [],
    activeHits: [],
  };
}

/** Build the bot's view from the true opponent state. */
export function buildBotView(
  trueBoard: Board,
  trueShips: PlacedShip[],
): BotView {
  // Bot can see hits/misses; only sunk ships' identities are known.
  const view: Board = trueBoard.map((row, r) =>
    row.map((cell, c) => {
      if (!cell.hit) return { shipId: null, hit: false };
      if (cell.shipId) {
        const ship = trueShips.find((s) => s.id === cell.shipId);
        return { shipId: ship?.sunk ? cell.shipId : null, hit: true };
      }
      return { shipId: null, hit: true };
    }),
  );

  const remainingShipSizes = trueShips.filter((s) => !s.sunk).map((s) => s.size);
  return { board: view, remainingShipSizes };
}

// ── Easy: uniform random ──────────────────────────────────────────────────
function chooseEasy(view: BotView): Position {
  const candidates: Position[] = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (!view.board[r][c].hit) candidates.push([r, c]);
    }
  }
  return candidates[Math.floor(Math.random() * candidates.length)];
}

// ── Medium: hunt + target ─────────────────────────────────────────────────
// Random hunt until first hit, then BFS adjacent cells until the ship sinks.
const ADJ: Position[] = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];

function chooseMedium(view: BotView, mem: BotMemory): Position {
  while (mem.pendingTargets.length > 0) {
    const target = mem.pendingTargets.shift()!;
    const [r, c] = target;
    if (inBounds(r, c) && !view.board[r][c].hit) return target;
  }
  // No targets queued → hunt
  return chooseEasy(view);
}

/** Update memory after a shot result. Mutates `mem` for convenience. */
export function updateBotMemory(
  mem: BotMemory,
  shot: Position,
  hit: boolean,
  sunk: boolean,
): void {
  if (hit) {
    if (sunk) {
      // Ship destroyed — clear active hit chain
      mem.activeHits = [];
      mem.pendingTargets = [];
    } else {
      mem.activeHits.push(shot);
      // Queue adjacent cells (filtered for already-shot when consumed)
      if (mem.activeHits.length === 1) {
        // First hit on a ship — queue all 4 neighbours
        for (const [dr, dc] of ADJ) {
          mem.pendingTargets.push([shot[0] + dr, shot[1] + dc]);
        }
      } else {
        // Second+ hit — we know the orientation; queue along that line
        const [r1, c1] = mem.activeHits[0];
        const [r2, c2] = shot;
        const dr = Math.sign(r2 - r1);
        const dc = Math.sign(c2 - c1);
        // Forward extension
        mem.pendingTargets.unshift([r2 + dr, c2 + dc]);
        // Backward extension (if forward miss later, we'll come back)
        mem.pendingTargets.push([r1 - dr, c1 - dc]);
      }
    }
  }
}

// ── Hard: probability density + parity hunt ───────────────────────────────
//
// Build a heatmap counting, for each unsearched cell, how many ways a remaining
// ship could be placed across that cell given current observations.
// This is the textbook "Battleship optimal" strategy used in countless analyses.

function buildHeatmap(view: BotView): number[][] {
  const heat = Array.from({ length: BOARD_SIZE }, () =>
    Array(BOARD_SIZE).fill(0),
  );

  for (const size of view.remainingShipSizes) {
    // Try each placement orientation; count if all cells are unshot or a hit.
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        for (const horizontal of [true, false] as const) {
          const cells: Position[] = [];
          let valid = true;
          for (let i = 0; i < size; i++) {
            const rr = horizontal ? r : r + i;
            const cc = horizontal ? c + i : c;
            if (!inBounds(rr, cc)) {
              valid = false;
              break;
            }
            const cell = view.board[rr][cc];
            // A placement is invalid if any cell is a known miss.
            if (cell.hit && !cell.shipId) {
              valid = false;
              break;
            }
            cells.push([rr, cc]);
          }
          if (valid) {
            for (const [rr, cc] of cells) {
              // Don't increment on already-hit cells (we don't shoot them again)
              if (!view.board[rr][cc].hit) heat[rr][cc]++;
            }
          }
        }
      }
    }
  }

  return heat;
}

function chooseHard(view: BotView, mem: BotMemory): Position {
  // If we have an active hit chain, prioritize medium-style targeting first
  // (adjacent cells), since that's the optimal local move.
  if (mem.activeHits.length > 0 && mem.pendingTargets.length > 0) {
    while (mem.pendingTargets.length > 0) {
      const target = mem.pendingTargets.shift()!;
      const [r, c] = target;
      if (inBounds(r, c) && !view.board[r][c].hit) return target;
    }
  }

  const heat = buildHeatmap(view);
  let best: Position = [0, 0];
  let bestScore = -1;
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (view.board[r][c].hit) continue;
      if (heat[r][c] > bestScore) {
        bestScore = heat[r][c];
        best = [r, c];
      }
    }
  }
  mem.lastHeatmapMax = bestScore;
  return best;
}

// ── Public API ────────────────────────────────────────────────────────────
export function chooseBotShot(view: BotView, mem: BotMemory): Position {
  switch (mem.difficulty) {
    case "easy":
      return chooseEasy(view);
    case "medium":
      return chooseMedium(view, mem);
    case "hard":
      return chooseHard(view, mem);
  }
}
