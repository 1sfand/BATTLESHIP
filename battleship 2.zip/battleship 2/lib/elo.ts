/**
 * Standard ELO calculation. K-factor 32 is fine for our scale.
 */
const K = 32;

export function expectedScore(ratingA: number, ratingB: number): number {
  return 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
}

export function eloDelta(winnerRating: number, loserRating: number): number {
  return Math.round(K * (1 - expectedScore(winnerRating, loserRating)));
}
