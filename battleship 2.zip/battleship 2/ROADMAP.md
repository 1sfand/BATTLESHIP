# Battleship — Roadmap & Progress

> Source-of-truth status. Read first when resuming. Update as you go.

**Stack:** Next.js 16 (App Router) · React 19 · TypeScript · Tailwind 4 · Zustand · Supabase · Vercel
**Package manager:** Bun (`~/.bun/bin/bun`)
**Run dev:** `bun run dev` from `~/battleship`
**Run tests:** `bun test`

---

## ✅ Done

### Foundation (session 1)
- [x] Next.js 16 + TS + Tailwind 4 scaffold
- [x] Pure game engine (`lib/engine`) — types, board, placement (no-touching rule), fire/sink, random fleet
- [x] Bot AI (`lib/ai/bot.ts`) — Easy / Medium (hunt-target) / Hard (probability density)
- [x] Zustand store + LocalStorage persistence
- [x] Theme system (`stores/theme.ts`) — dark/light free, locked themes scaffolded
- [x] UI: Board, FleetStatus, SetupPanel, GameView orchestrator
- [x] Routes `/` `/play/bot` `/play/local`
- [x] Engine + bot AI tests passing

### Cloud + features (session 2)
- [x] Supabase schema — `0001_init.sql` (profiles + games + story_progress + ELO function + leaderboard view)
- [x] RLS — `0002_rls.sql`
- [x] Online schema — `0003_online.sql` (`online_rooms`, realtime publication)
- [x] Supabase clients (browser/server/proxy session refresh)
- [x] Auth pages: `/auth/sign-in` (Google + email magic-link + guest), callback
- [x] `proxy.ts` (Next.js 16 renamed middleware)
- [x] Profile page with editable nickname/avatar + stats
- [x] Leaderboard `/leaderboard` (top 100 by ELO)
- [x] My Stats `/stats` (W/L, accuracy, recent games + replay links)
- [x] `/api/games/save` — persists finished games + bumps stats + applies bot-ELO
- [x] Replay viewer `/replay/[id]` — scrubber, play/pause, 1×/2×/4× speed
- [x] Replay reconstruction (`lib/replay/reconstruct.ts`) — pure, deterministic
- [x] **AI Advisor** `/api/advisor` — streams Claude Haiku 4.5 commentary per move, caches in `games.advisor_commentary`
- [x] Story mode — chapters data file, intro/outro dialogue, theme unlock on win
- [x] Story routes `/story` index + `/story/[chapter]` runner
- [x] Online multiplayer — `/play/online` lobby (create/join by 6-letter code) + `/play/online/[id]` room (Supabase Realtime sync)
- [x] Auth header on home with avatar pill + ELO + sign-out
- [x] All routes build clean ✓

---

## 🔜 Next up

### Phase 7 — Polish & deploy (task #10)

Order of work for next session:

#### 1. Provision Supabase project
- [ ] Create project at supabase.com (free tier, region close to you)
- [ ] **Settings → API:** copy `Project URL` + `anon public` key into `.env.local`:
      ```
      NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
      NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
      ```
- [ ] **SQL Editor → New query:** paste & run `supabase/migrations/0001_init.sql`, then `0002_rls.sql`, then `0003_online.sql` (in order)
- [ ] **Authentication → Providers:** enable Google (paste OAuth client id/secret from Google Cloud Console) and email; enable anonymous sign-in
- [ ] **Authentication → URL Configuration:** add `http://localhost:3000/auth/callback` to Redirect URLs (and your Vercel domain later)

#### 2. Anthropic API key (for AI advisor)
- [ ] https://console.anthropic.com → API Keys → Create
- [ ] Add `ANTHROPIC_API_KEY=sk-ant-…` to `.env.local`
- [ ] (Replays will gracefully say "advisor offline" if missing)

#### 3. Mobile + touch polish
- [ ] Replace hover-preview with tap-to-select-then-tap-to-place flow on touch
- [ ] Long-press to rotate ship instead of `R` key
- [ ] Min-board-size + scrolling on small screens
- [ ] Test all routes on a 375px viewport

#### 4. Sound + animation polish
- [ ] Sound FX: ship-place click, miss-splash, hit-explosion, victory chime (toggleable in profile)
- [ ] Subtle wave animation on idle boards
- [ ] Confetti or ship-debris animation on victory

#### 5. PWA + SEO
- [ ] `app/manifest.ts` (PWA-installable)
- [ ] `app/icon.tsx` + `app/apple-icon.tsx` (dynamic)
- [ ] OG image generator for replay shares (`app/replay/[id]/opengraph-image.tsx`)
- [ ] Robots + sitemap

#### 6. Deploy
- [ ] `bun add -d vercel` or use Vercel CLI directly
- [ ] `vercel link` then `vercel env pull` (or set env in dashboard)
- [ ] `vercel --prod`
- [ ] Add prod URL to Supabase Authentication → URL Configuration
- [ ] Verify auth flow end-to-end on prod

#### 7. Optional / future
- [ ] Reconnect handling for online matches (timer-based forfeit)
- [ ] Spectator mode for online matches via shareable link
- [ ] Daily puzzle: deterministic seed, single-player vs bot, timed
- [ ] Custom board sizes (small/medium/large)
- [ ] Power-ups (radar reveal, airstrike) as story unlocks
- [ ] Friend list + direct invites
- [ ] More story chapters (4–10) with branching paths
- [ ] Generated `Database` types via `supabase gen types typescript` (replace hand-typed `lib/supabase/types.ts`)

---

## 🗒 Architecture notes

- **Bot doesn't cheat:** `buildBotView` strips `shipId` from cells unless the ship is publicly sunk.
- **Replay is deterministic:** initial ship placements + move log → exact board state at any move. Stored in `games.initial_state` + `games.moves`.
- **Online sync:** moves are appended to `online_rooms.moves` jsonb array; opponents subscribe via Supabase Realtime `postgres_changes`. State is reconstructed locally from initial states + moves on every update.
- **Themes:** `stores/theme.ts` tracks unlocked set in LocalStorage (synced to `story_progress.unlocks` server-side after story chapter wins). Free: dark, light. Locked: naval (ch.2), neon (ch.3), retro, paper.
- **ELO:** K=32 standard formula. Bot baseline rating depends on difficulty (1100/1300/1500). PvP applied via `apply_elo()` SQL function once we hook it into online game-end.
- **Ships can't touch** — implemented in `isValidPlacement` (checks 8 neighbours).

## 📁 Where things live

```
app/                          Next.js routes
  api/advisor/route.ts        Claude streaming endpoint
  api/games/save/route.ts     Save finished game record
  auth/sign-in/                Sign-in page + form
  auth/callback/route.ts      OAuth/magic-link handler
  play/bot|local/             Offline modes
  play/online/[id]/            Realtime online match
  story/[chapter]/             Chapter runner
  replay/[id]/                Replay viewer with AI advisor
  leaderboard, stats, profile
lib/engine/                   Pure game logic (no DOM)
lib/ai/bot.ts                 3 difficulty levels
lib/replay/reconstruct.ts     Deterministic state replay
lib/story/chapters.ts         Story data
lib/supabase/                 Browser + server + proxy clients
lib/elo.ts                    ELO formula
stores/game.ts                Zustand: hot-seat & vs-bot
stores/theme.ts               Theme state + unlocks
components/game/              Board, FleetStatus, SetupPanel, GameView
components/auth/AuthHeader    Pill in top-right
components/theme/             Provider + toggle
hooks/useAuth.ts              Subscribes to Supabase auth
supabase/migrations/          0001_init, 0002_rls, 0003_online
proxy.ts                      Session refresh on every request
```

## 🧪 Testing

- Engine: `bun test lib/engine/engine.test.ts`
- Bot: `bun test lib/ai/bot.test.ts` (validates Hard < Medium < Easy avg shots)

## 🪦 Archived

Original vanilla-JS prototype at `~/battleship-vanilla-prototype/`.
