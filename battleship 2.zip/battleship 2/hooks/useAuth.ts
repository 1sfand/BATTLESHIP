"use client";

import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { getSupabaseBrowser } from "@/lib/supabase/client";
import type { ProfileRow } from "@/lib/supabase/types";

interface AuthState {
  loading: boolean;
  user: User | null;
  profile: ProfileRow | null;
  configured: boolean;
}

/**
 * Subscribes to Supabase auth state. If Supabase isn't configured (no env
 * vars), `configured: false` is returned and components should fall back to
 * "guest only" UI.
 */
export function useAuth(): AuthState {
  const [state, setState] = useState<AuthState>({
    loading: true,
    user: null,
    profile: null,
    configured: false,
  });

  useEffect(() => {
    const supabase = getSupabaseBrowser();
    if (!supabase) {
      setState({ loading: false, user: null, profile: null, configured: false });
      return;
    }

    let cancelled = false;

    const loadProfile = async (user: User | null) => {
      if (!user) {
        if (!cancelled) {
          setState({ loading: false, user: null, profile: null, configured: true });
        }
        return;
      }
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();
      if (!cancelled) {
        setState({ loading: false, user, profile: profile ?? null, configured: true });
      }
    };

    supabase.auth.getUser().then((res: { data: { user: User | null } }) =>
      loadProfile(res.data.user ?? null),
    );

    const { data: sub } = supabase.auth.onAuthStateChange(
      (_event: string, session: { user: User | null } | null) => {
        loadProfile(session?.user ?? null);
      },
    );

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  return state;
}
