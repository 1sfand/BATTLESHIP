"use client";

import { useState } from "react";
import { cn } from "@/lib/utils/cn";

interface Props {
  /** Optional replay id — included in the share url if present. */
  replayId?: string | null;
  /** Display name of the winning side ("You", or a nickname). */
  winnerName: string;
  shots: number;
  hits: number;
  durationSeconds?: number | null;
  /** Optional difficulty label, e.g. "hard". */
  difficulty?: string | null;
}

export function ShareVictory({
  replayId,
  winnerName,
  shots,
  hits,
  durationSeconds,
  difficulty,
}: Props) {
  const [copied, setCopied] = useState(false);

  const accuracy = shots > 0 ? Math.round((hits / shots) * 100) : 0;
  const url = typeof window !== "undefined"
    ? `${window.location.origin}${replayId ? `/replay/${replayId}` : ""}`
    : "";

  const text = [
    `⚓ Just sank the fleet${difficulty ? ` on ${difficulty.toUpperCase()}` : ""}!`,
    `${shots} shots · ${accuracy}% accuracy${durationSeconds ? ` · ${formatDuration(durationSeconds)}` : ""}`,
    replayId ? "Watch the replay 👇" : "",
  ].filter(Boolean).join("\n");

  const tweetUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`;
  const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  const redditUrl = `https://www.reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(`Battleship victory by ${winnerName}`)}`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${text}\n${url}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Older browsers — fallback
      window.prompt("Copy link:", `${text}\n${url}`);
    }
  };

  const nativeShare = async () => {
    if (typeof navigator === "undefined" || !navigator.share) return;
    try {
      await navigator.share({ title: "Battleship victory", text, url });
    } catch {
      // User canceled — ignore
    }
  };

  const canNativeShare = typeof navigator !== "undefined" && !!navigator.share;

  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-border bg-surface p-4">
      <p className="text-[10px] font-bold uppercase tracking-widest text-accent">
        Share your victory
      </p>
      <div className="flex flex-wrap items-center justify-center gap-2">
        {canNativeShare && (
          <ShareLink onClick={nativeShare} label="📱 Share">Share</ShareLink>
        )}
        <ShareLink href={tweetUrl} label="X / Twitter">𝕏</ShareLink>
        <ShareLink href={whatsappUrl} label="WhatsApp">💬</ShareLink>
        <ShareLink href={telegramUrl} label="Telegram">✈</ShareLink>
        <ShareLink href={redditUrl} label="Reddit">👽</ShareLink>
        <button
          onClick={copyLink}
          className={cn(
            "rounded-md border px-3 py-1.5 text-xs font-bold transition",
            copied
              ? "border-green bg-green/10 text-green"
              : "border-border bg-surface-2 text-text-dim hover:border-accent hover:text-text",
          )}
        >
          {copied ? "✓ Copied" : "🔗 Copy link"}
        </button>
      </div>
    </div>
  );
}

function ShareLink({
  href,
  onClick,
  label,
  children,
}: {
  href?: string;
  onClick?: () => void;
  label: string;
  children: React.ReactNode;
}) {
  const className =
    "inline-flex size-8 items-center justify-center rounded-md border border-border bg-surface-2 text-base hover:border-accent";
  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className={className}>
        {children}
      </a>
    );
  }
  return (
    <button onClick={onClick} aria-label={label} className={className} type="button">
      {children}
    </button>
  );
}

function formatDuration(s: number): string {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}m ${r}s` : `${r}s`;
}
