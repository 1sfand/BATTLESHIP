import { getLeague } from "@/lib/league";
import { cn } from "@/lib/utils/cn";

interface Props {
  rating: number;
  size?: "xs" | "sm" | "md";
  showRating?: boolean;
}

export function LeagueBadge({ rating, size = "sm", showRating = false }: Props) {
  const league = getLeague(rating);
  const sizeCls =
    size === "xs"
      ? "text-[9px] px-1.5 py-0.5 gap-1"
      : size === "md"
        ? "text-sm px-3 py-1.5 gap-2"
        : "text-[10px] px-2 py-0.5 gap-1.5";

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border font-bold uppercase tracking-wider",
        league.badge,
        sizeCls,
      )}
      title={`${league.name} · ${league.motto}`}
    >
      <span aria-hidden>{league.symbol}</span>
      <span>{league.name}</span>
      {showRating && (
        <span className="ml-1 opacity-70">{rating}</span>
      )}
    </span>
  );
}
