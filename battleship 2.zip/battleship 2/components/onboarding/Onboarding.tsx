"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const STORAGE_KEY = "battleship_onboarding_v1";

interface Step {
  emoji: string;
  title: string;
  body: React.ReactNode;
  /** Optional CTA shown alongside Next/Skip. */
  cta?: { href: string; label: string };
}

const STEPS: Step[] = [
  {
    emoji: "⚓",
    title: "Welcome aboard, admiral",
    body: (
      <>
        Battleship is a turn-based naval duel. You hide a fleet on a 10×10 grid,
        your opponent does the same, then you take turns firing at coordinates
        until one fleet is destroyed.
      </>
    ),
  },
  {
    emoji: "🚢",
    title: "Place your fleet",
    body: (
      <>
        Five ships, sizes 5/4/3/3/2. Click on the grid to place each ship — hover
        to preview, press <kbd className="rounded bg-surface-2 px-1.5 py-0.5 text-[11px]">R</kbd>{" "}
        to rotate. Or hit "🎲 Random Placement" for an instant valid layout.
        <br />
        <span className="mt-2 block text-xs text-text-dim">
          Important: ships cannot touch — leave at least 1 empty cell between them.
        </span>
      </>
    ),
  },
  {
    emoji: "🎯",
    title: "Fire at coordinates",
    body: (
      <>
        Click any cell on the <strong>Enemy Waters</strong> grid to fire.
        A red X is a hit; a small dot is a miss. After three hits on a 3-cell ship,
        the entire ship is sunk and revealed.
        <br />
        <span className="mt-2 block text-xs text-text-dim">
          Tip: when you score a hit, the next shot should almost always be one of
          the four neighbouring cells.
        </span>
      </>
    ),
  },
  {
    emoji: "🤖",
    title: "Three difficulty levels",
    body: (
      <>
        <strong>Easy</strong> shoots randomly.{" "}
        <strong>Medium</strong> hunts adjacent cells once it scores a hit.{" "}
        <strong>Hard</strong> uses a probability heatmap and plays optimally —
        even strong human players lose to it.
      </>
    ),
    cta: { href: "/play/bot", label: "Try Vs Bot" },
  },
  {
    emoji: "🏅",
    title: "Climb the leagues",
    body: (
      <>
        Every ranked game updates your ELO. Climb from{" "}
        <span className="text-orange-300">Bronze</span> →{" "}
        <span className="text-slate-200">Silver</span> →{" "}
        <span className="text-amber-300">Gold</span> →{" "}
        <span className="text-sky-200">Platinum</span> →{" "}
        <span className="text-cyan-300">Diamond</span>. Each league has its own
        leaderboard.
      </>
    ),
    cta: { href: "/leaderboard", label: "See leaderboard" },
  },
  {
    emoji: "📜",
    title: "Story mode unlocks themes",
    body: (
      <>
        Three named admirals — Lt. Volkov, Cmdr. Hale, Adm. Kestrel — each tougher
        than the last. Defeat them to unlock cosmetic themes you can switch to
        anytime via the 🎨 picker in the top-right.
      </>
    ),
    cta: { href: "/story", label: "Begin the campaign" },
  },
  {
    emoji: "🌐",
    title: "Play online",
    body: (
      <>
        Use <strong>Quick Match</strong> to find a random opponent in your league,
        or create a <strong>Private room</strong> and share the 6-letter code with
        a friend. Realtime multiplayer over WebSockets — no install needed.
      </>
    ),
    cta: { href: "/play/online", label: "Find a match" },
  },
  {
    emoji: "🏛",
    title: "Learn the game",
    body: (
      <>
        The Naval Academy has bite-sized lessons on probability targeting,
        placement theory, and the history of naval battles. First two lessons
        free, the rest unlocks with the Admiral's Pass.
      </>
    ),
    cta: { href: "/academy", label: "Open the Academy" },
  },
];

export function Onboarding() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    try {
      const seen = localStorage.getItem(STORAGE_KEY);
      if (!seen) setOpen(true);
    } catch {
      // localStorage unavailable — show anyway
      setOpen(true);
    }
  }, []);

  if (!open) return null;

  const close = () => {
    try { localStorage.setItem(STORAGE_KEY, "1"); } catch {}
    setOpen(false);
  };

  const s = STEPS[step];
  const isLast = step === STEPS.length - 1;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-bg/85 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="onboarding-title"
    >
      <div className="w-full max-w-md overflow-hidden rounded-2xl border border-border bg-surface shadow-xl">
        {/* progress bar */}
        <div className="h-1 w-full bg-surface-2">
          <div
            className="h-full bg-accent transition-all"
            style={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
          />
        </div>

        <div className="px-6 pt-6 pb-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
              {step + 1} / {STEPS.length}
            </span>
            <button
              onClick={close}
              aria-label="Skip onboarding"
              className="text-text-dim hover:text-hit"
            >
              ✕
            </button>
          </div>

          <div className="text-5xl">{s.emoji}</div>
          <h2 id="onboarding-title" className="mt-3 text-xl font-bold">
            {s.title}
          </h2>
          <div className="mt-2 text-sm leading-relaxed text-text-dim">
            {s.body}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border bg-surface-2 px-6 py-3">
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
            className="text-xs text-text-dim hover:text-accent disabled:opacity-30"
          >
            ← Back
          </button>

          <div className="flex items-center gap-2">
            {s.cta && (
              <Link
                href={s.cta.href}
                onClick={close}
                className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-bold hover:border-accent"
              >
                {s.cta.label}
              </Link>
            )}
            {isLast ? (
              <button
                onClick={close}
                className="rounded-md bg-accent px-4 py-1.5 text-xs font-bold text-white hover:opacity-90"
              >
                Let's play ⚔
              </button>
            ) : (
              <button
                onClick={() => setStep(step + 1)}
                className="rounded-md bg-accent px-4 py-1.5 text-xs font-bold text-white hover:opacity-90"
              >
                Next →
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Re-show the onboarding (used by a "Show tutorial" link). Clears the seen flag.
 */
export function resetOnboarding() {
  try { localStorage.removeItem(STORAGE_KEY); } catch {}
  // Force a remount via location (simplest)
  if (typeof window !== "undefined") window.location.reload();
}
