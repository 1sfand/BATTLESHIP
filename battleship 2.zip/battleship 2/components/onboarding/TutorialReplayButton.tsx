"use client";

import { resetOnboarding } from "./Onboarding";

export function TutorialReplayButton() {
  return (
    <button
      onClick={resetOnboarding}
      className="hover:text-accent"
    >
      💡 Show tutorial
    </button>
  );
}
