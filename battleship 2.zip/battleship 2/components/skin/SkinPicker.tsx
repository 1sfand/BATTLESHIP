"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSkinStore } from "@/stores/skin";
import { SKINS } from "@/lib/skins/skins";

export function SkinPicker() {
  const { skin, setSkin, isUnlocked } = useSkinStore();
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  if (!mounted) return <div className="size-9" />;

  const current = SKINS.find((s) => s.id === skin) ?? SKINS[0];
  const previewIcon = current.icons.battleship ?? "🚢";

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        aria-label="Pick a ship skin"
        className="flex size-9 items-center justify-center rounded-lg border border-border bg-surface text-base hover:border-accent"
      >
        {previewIcon}
      </button>

      {open && (
        <div className="absolute right-0 top-11 z-50 w-72 overflow-hidden rounded-xl border border-border bg-surface shadow-lg">
          <div className="border-b border-border bg-surface-2 px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
            Ship Skins
          </div>
          <ul className="max-h-96 overflow-auto py-1">
            {SKINS.map((s) => {
              const unlocked = isUnlocked(s.id);
              const active = s.id === skin;
              return (
                <li key={s.id}>
                  <button
                    disabled={!unlocked}
                    onClick={() => {
                      if (unlocked) {
                        setSkin(s.id);
                        setOpen(false);
                      }
                    }}
                    className={`flex w-full items-center gap-3 px-3 py-2.5 text-left transition ${
                      active ? "bg-accent/15 text-text" : "hover:bg-surface-2"
                    } ${!unlocked ? "cursor-not-allowed opacity-60" : ""}`}
                  >
                    {/* preview tile of all 5 sizes */}
                    <div className="flex shrink-0 items-center gap-0.5">
                      {(["destroyer", "submarine", "cruiser", "battleship", "carrier"] as const).map(
                        (sid) => {
                          const ic = s.icons[sid];
                          return (
                            <div
                              key={sid}
                              className="grid size-5 place-items-center rounded-sm border border-border-2 bg-ship text-[11px]"
                              aria-hidden
                            >
                              {ic ?? ""}
                            </div>
                          );
                        },
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1 text-sm font-medium">
                        <span className="truncate">{s.name}</span>
                        {active && <span className="text-accent">✓</span>}
                        {!unlocked && (
                          <span className="ml-auto rounded bg-accent-2/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-accent-2">
                            Pro
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 text-[11px] leading-tight text-text-dim">
                        {s.blurb}
                      </p>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="border-t border-border bg-surface-2 px-3 py-2">
            <Link
              href="/upgrade"
              onClick={() => setOpen(false)}
              className="text-[11px] text-accent hover:underline"
            >
              👑 Unlock all skins →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
