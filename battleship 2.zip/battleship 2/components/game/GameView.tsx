"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

import { Board } from "./Board";
import { FleetStatus } from "./FleetStatus";
import { SetupPanel } from "./SetupPanel";
import { ShareVictory } from "@/components/share/ShareVictory";
import { useGameStore } from "@/stores/game";
import {
  SHIP_DEFS,
  censorBoard,
  getPositions,
  isValidPlacement,
} from "@/lib/engine";
import type { Difficulty } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";

interface GameViewProps {
  mode: "bot" | "local";
}

export function GameView({ mode }: GameViewProps) {
  const router = useRouter();
  const game = useGameStore((s) => s.game);
  const startBotGame = useGameStore((s) => s.startBotGame);
  const startLocalGame = useGameStore((s) => s.startLocalGame);
  const reset = useGameStore((s) => s.reset);

  // Show difficulty picker if no game in progress for this mode
  const wrongMode = game && game.mode !== mode;
  const noGame = !game || wrongMode;

  if (noGame && mode === "bot") {
    return <DifficultyPicker onPick={(d) => startBotGame(d)} />;
  }
  if (noGame && mode === "local") {
    return <LocalIntro onStart={() => startLocalGame()} />;
  }
  if (!game) return null;

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-6">
      <div className="mb-4 flex w-full max-w-5xl items-center justify-between">
        <Link
          href="/"
          onClick={() => {
            if (game.phase === "gameover") reset();
          }}
          className="text-sm text-text-dim hover:text-accent"
        >
          ← Home
        </Link>
        <div className="text-xs uppercase tracking-widest text-text-dim">
          {game.mode === "bot" ? `Vs Bot · ${game.difficulty}` : "Hot-seat"}
        </div>
        <button
          onClick={() => {
            reset();
            router.push("/");
          }}
          className="text-sm text-text-dim hover:text-hit"
        >
          End Game
        </button>
      </div>

      {game.phase === "setup" && <SetupPhase />}
      {game.phase === "pass" && <PassPhase />}
      {game.phase === "battle" && <BattlePhase />}
      {game.phase === "gameover" && <GameOverPhase />}
    </main>
  );
}

// ─── Difficulty / intro screens ───────────────────────────────────────────

function DifficultyPicker({ onPick }: { onPick: (d: Difficulty) => void }) {
  const opts: { id: Difficulty; title: string; desc: string }[] = [
    { id: "easy", title: "Easy", desc: "Random shots. Good for warm-up." },
    {
      id: "medium",
      title: "Medium",
      desc: "Hunts your ships once it lands a hit.",
    },
    {
      id: "hard",
      title: "Hard",
      desc: "Probability-based targeting. Plays optimally.",
    },
  ];
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>
      <h1 className="title-gradient text-3xl font-black uppercase tracking-wider">
        Vs Bot
      </h1>
      <p className="mt-2 text-sm text-text-dim">Choose difficulty</p>
      <div className="mt-8 grid w-full max-w-2xl gap-3 md:grid-cols-3">
        {opts.map((o) => (
          <button
            key={o.id}
            onClick={() => onPick(o.id)}
            className="rounded-xl border border-border bg-surface p-5 text-left transition hover:-translate-y-0.5 hover:border-accent"
          >
            <div className="text-xl font-bold capitalize">{o.title}</div>
            <p className="mt-1 text-xs text-text-dim">{o.desc}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

function LocalIntro({ onStart }: { onStart: () => void }) {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>
      <h1 className="title-gradient text-3xl font-black uppercase tracking-wider">
        Local 2-Player
      </h1>
      <p className="mt-2 max-w-md text-center text-sm text-text-dim">
        Pass the device between turns. Player 1 places first, then Player 2.
      </p>
      <button
        onClick={onStart}
        className="mt-8 rounded-md bg-accent px-6 py-3 text-base font-bold text-white hover:opacity-90"
      >
        Start Match
      </button>
    </main>
  );
}

// ─── Setup phase ──────────────────────────────────────────────────────────

function SetupPhase() {
  const game = useGameStore((s) => s.game)!;
  const setOrientation = useGameStore((s) => s.setOrientation);
  const toggleOrientation = useGameStore((s) => s.toggleOrientation);
  const placeAt = useGameStore((s) => s.placeAt);
  const randomize = useGameStore((s) => s.randomizeCurrentPlayer);
  const confirm = useGameStore((s) => s.confirmSetup);

  const [hover, setHover] = useState<{ row: number; col: number } | null>(null);

  // Keyboard: R rotates
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "r" || e.key === "R") toggleOrientation();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggleOrientation]);

  const player = game.players[game.setupPlayer];
  const def = SHIP_DEFS[game.placingIndex];

  const preview = useCallback(() => {
    if (!hover || !def) return null;
    const positions = getPositions(
      hover.row,
      hover.col,
      def.size,
      game.horizontal,
    );
    const valid = isValidPlacement(player.board, positions);
    return { positions, valid };
  }, [hover, def, game.horizontal, player.board])();

  return (
    <div className="flex w-full max-w-5xl flex-col items-center gap-6 md:flex-row md:items-start md:justify-center">
      <SetupPanel
        placingIndex={game.placingIndex}
        horizontal={game.horizontal}
        onOrientation={setOrientation}
        onRandom={randomize}
        onConfirm={confirm}
      />
      <div className="flex flex-col items-center gap-3">
        <div className="rounded-full border border-accent bg-surface px-4 py-1 text-xs font-bold uppercase tracking-wider text-accent">
          ⚓ {player.name} — Place Your Fleet
        </div>
        <Board
          board={player.board}
          ships={player.ships}
          mode="setup"
          preview={preview as { positions: [number, number][]; valid: boolean } | null}
          onCellEnter={(row, col) => setHover({ row, col })}
          onCellLeave={() => setHover(null)}
          onCellClick={(row, col) => placeAt(row, col)}
        />
        {def && (
          <div className="text-xs text-text-dim">
            Placing:{" "}
            <strong className="text-text">{def.name}</strong> ({def.size} cells)
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Pass phase ───────────────────────────────────────────────────────────

function PassPhase() {
  const game = useGameStore((s) => s.game)!;
  const confirmPass = useGameStore((s) => s.confirmPass);

  let icon = "🔄";
  let title = "Pass the device";
  let sub = "";
  let label = "Continue";

  if (game.passReason === "setup-done") {
    const next = game.players[game.setupPlayer];
    title = `Hand it to ${next.name}`;
    sub = `${next.name} will now place their fleet. Don't peek!`;
    label = "Ready — Place Fleet";
  } else if (game.passReason === "battle-start") {
    const p = game.players[game.battlePlayer];
    icon = "⚔";
    title = `${p.name}, you're up!`;
    sub = "The battle begins. Choose your targets wisely.";
    label = "Begin Battle";
  } else if (game.passReason === "battle-switch") {
    const p = game.players[game.battlePlayer];
    title = `Pass to ${p.name}`;
    sub = "Don't let your opponent see your board.";
    label = `I'm ${p.name} — Ready`;
  }

  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-5 text-center animate-fade-in-up">
      <div className="text-6xl">{icon}</div>
      <h2 className="text-3xl font-black">{title}</h2>
      <p className="max-w-sm text-sm text-text-dim">{sub}</p>
      <button
        onClick={confirmPass}
        className="rounded-md bg-accent px-6 py-3 text-base font-bold text-white hover:opacity-90"
      >
        {label}
      </button>
    </div>
  );
}

// ─── Battle phase ─────────────────────────────────────────────────────────

function BattlePhase() {
  const game = useGameStore((s) => s.game)!;
  const fireAtCell = useGameStore((s) => s.fireAtCell);
  const runBotTurn = useGameStore((s) => s.runBotTurn);

  const isBot = game.mode === "bot";
  const isBotTurn = isBot && game.battlePlayer === 1;

  // Trigger bot turn after a short delay (so the UI shows the previous shot result)
  useEffect(() => {
    if (!isBotTurn) return;
    const t = setTimeout(() => runBotTurn(), 850);
    return () => clearTimeout(t);
  }, [isBotTurn, game.moves.length, runBotTurn]);

  const attackerIdx = game.battlePlayer;
  const attacker = game.players[attackerIdx];
  const defender = game.players[(attackerIdx ^ 1) as 0 | 1];

  const status = game.lastShot
    ? game.lastShot.sunkShipName
      ? { msg: `💥 SUNK! ${game.lastShot.sunkShipName} destroyed.`, cls: "border-hit text-hit" }
      : game.lastShot.hit
        ? { msg: "🎯 Direct hit!", cls: "border-hit text-hit" }
        : { msg: "💧 Miss.", cls: "border-border text-miss" }
    : { msg: "Select a target on the enemy grid", cls: "border-border text-text-dim" };

  return (
    <div className="flex w-full max-w-6xl flex-col items-center gap-5">
      <div className="flex flex-wrap items-center justify-center gap-3">
        <div className="rounded-full bg-gradient-to-r from-accent to-blue-700 px-4 py-1 text-sm font-bold text-white shadow-md">
          ⚔ {attacker.name}{isBotTurn ? " is firing…" : "'s Turn"}
        </div>
        <div className={cn(
          "min-w-[260px] rounded-md border bg-surface px-4 py-2 text-center text-sm font-medium",
          status.cls,
        )}>
          {status.msg}
        </div>
      </div>

      <div className="flex flex-col items-start justify-center gap-8 md:flex-row">
        <BattleBoard
          title={`Your Waters — ${attacker.name}`}
          board={attacker.board}
          ships={attacker.ships}
          mode="own"
        />
        <BattleBoard
          title={`Enemy Waters — ${defender.name}`}
          board={censorBoard(defender.board)}
          ships={defender.ships}
          mode="target"
          onCellClick={(r, c) => !isBotTurn && fireAtCell(r, c)}
          hideShipNames
        />
      </div>
    </div>
  );
}

function BattleBoard({
  title,
  board,
  ships,
  mode,
  onCellClick,
  hideShipNames = false,
}: {
  title: string;
  board: import("@/lib/engine").Board;
  ships: import("@/lib/engine").PlacedShip[];
  mode: "own" | "target";
  onCellClick?: (r: number, c: number) => void;
  hideShipNames?: boolean;
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
        {title}
      </div>
      <Board board={board} ships={ships} mode={mode} onCellClick={onCellClick} />
      <FleetStatus ships={ships} board={board} hideIntact={hideShipNames} />
    </div>
  );
}

// ─── Game-over phase ──────────────────────────────────────────────────────

function GameOverPhase() {
  const game = useGameStore((s) => s.game)!;
  const reset = useGameStore((s) => s.reset);
  const router = useRouter();
  const [savedId, setSavedId] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Save game record to Supabase exactly once on game-over.
  useEffect(() => {
    if (savedId || saveError) return;
    if (game.mode !== "bot") return; // only auto-save bot games for now
    let cancelled = false;
    fetch("/api/games/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ game }),
    })
      .then(async (r) => {
        if (cancelled) return;
        if (r.status === 503 || r.status === 401) {
          setSaveError("offline"); // expected when not signed in / not configured
          return;
        }
        const json = await r.json().catch(() => null);
        if (r.ok && json?.id) setSavedId(json.id);
        else setSaveError(json?.error ?? "save_failed");
      })
      .catch(() => !cancelled && setSaveError("save_failed"));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const winnerIdx = game.winner!;
  const winner = game.players[winnerIdx];
  const loser = game.players[(winnerIdx ^ 1) as 0 | 1];

  const ws = game.stats[winnerIdx];
  const ls = game.stats[(winnerIdx ^ 1) as 0 | 1];
  const acc = (s: { shots: number; hits: number }) =>
    s.shots > 0 ? Math.round((s.hits / s.shots) * 100) : 0;

  const playAgain = () => {
    if (game.mode === "bot") {
      // re-pick difficulty
      reset();
      router.refresh();
    } else {
      reset();
      router.push("/play/local");
    }
  };

  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center animate-fade-in-up">
      <div className="text-7xl">🏆</div>
      <h2 className="text-4xl font-black">Victory!</h2>
      <p className="text-lg text-accent-2">{winner.name} wins the battle</p>

      <div className="mt-2 grid w-full max-w-sm grid-cols-2 gap-3">
        <Stat label={`${winner.name} shots`} value={ws.shots} />
        <Stat label="Accuracy" value={`${acc(ws)}%`} />
        <Stat label={`${loser.name} shots`} value={ls.shots} />
        <Stat label={`${loser.name} accuracy`} value={`${acc(ls)}%`} />
      </div>

      {/* Share buttons — only show when the human won */}
      {winnerIdx === 0 && (
        <ShareVictory
          replayId={savedId}
          winnerName={winner.name}
          shots={ws.shots}
          hits={ws.hits}
          durationSeconds={
            game.endedAt && game.startedAt
              ? Math.round((game.endedAt - game.startedAt) / 1000)
              : null
          }
          difficulty={game.difficulty}
        />
      )}

      <div className="mt-4 flex flex-wrap justify-center gap-3">
        <button
          onClick={playAgain}
          className="rounded-md bg-accent px-6 py-3 text-sm font-bold text-white hover:opacity-90"
        >
          ⚔ Play Again
        </button>
        {savedId && (
          <Link
            href={`/replay/${savedId}`}
            className="rounded-md border border-accent bg-surface px-6 py-3 text-sm font-bold text-accent hover:bg-surface-2"
          >
            ▶ Watch Replay
          </Link>
        )}
        <Link
          href="/"
          onClick={() => reset()}
          className="rounded-md border border-border bg-surface px-6 py-3 text-sm font-bold hover:border-accent"
        >
          Main Menu
        </Link>
      </div>
      {saveError === "offline" && (
        <p className="text-[11px] text-text-dim">
          Sign in to save replays and earn ELO.
        </p>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-border bg-surface p-3">
      <div className="text-2xl font-black text-accent">{value}</div>
      <div className="text-[10px] uppercase tracking-widest text-text-dim">
        {label}
      </div>
    </div>
  );
}
