"use client";

import { SHIP_DEFS } from "@/lib/engine";
import type { Board, PlacedShip } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";

interface Props {
  ships: PlacedShip[];
  board: Board;
  /** Hide ship names if intact (used for enemy fleet status). */
  hideIntact?: boolean;
}

export function FleetStatus({ ships, board, hideIntact = false }: Props) {
  return (
    <div className="flex w-full max-w-[200px] flex-col gap-1">
      {SHIP_DEFS.map((def) => {
        const ship = ships.find((s) => s.id === def.id);
        if (!ship) return null;

        return (
          <div
            key={def.id}
            className={cn(
              "flex items-center gap-2 text-xs",
              ship.sunk && "opacity-50 line-through",
            )}
          >
            <span className="flex-1 truncate text-text-dim">
              {hideIntact && !ship.sunk ? "???" : def.name}
            </span>
            <div className="flex gap-px">
              {ship.positions.map(([r, c], i) => {
                const cellHit = board[r][c].hit;
                return (
                  <span
                    key={i}
                    className={cn(
                      "block size-2.5 rounded-sm border",
                      cellHit
                        ? "bg-hit border-hit"
                        : "bg-ship border-accent",
                    )}
                  />
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
