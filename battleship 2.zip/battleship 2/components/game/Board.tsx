"use client";

import { useMemo } from "react";
import { BOARD_SIZE, COLS } from "@/lib/engine";
import type { Board, PlacedShip, ShipId } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";
import { useSkinStore } from "@/stores/skin";
import { getSkin } from "@/lib/skins/skins";

export type BoardMode =
  | "setup"   // your own board during placement; show ships, accept hover/click
  | "own"     // your own board during battle; show ships + incoming hits
  | "target"; // opponent's board; only show hits/misses, click to fire

interface BoardProps {
  board: Board;
  ships: PlacedShip[];
  mode: BoardMode;
  /** Setup-mode ship preview cells (highlighted on hover). */
  preview?: { positions: [number, number][]; valid: boolean } | null;
  onCellEnter?: (row: number, col: number) => void;
  onCellLeave?: () => void;
  onCellClick?: (row: number, col: number) => void;
}

export function Board({
  board,
  ships,
  mode,
  preview,
  onCellEnter,
  onCellLeave,
  onCellClick,
}: BoardProps) {
  const skinId = useSkinStore((s) => s.skin);
  const skin = getSkin(skinId);

  const sunkIds = useMemo(
    () => new Set(ships.filter((s) => s.sunk).map((s) => s.id)),
    [ships],
  );

  const previewSet = useMemo(() => {
    if (!preview) return null;
    return new Set(preview.positions.map(([r, c]) => `${r}:${c}`));
  }, [preview]);

  const showShips = mode === "setup" || mode === "own";

  return (
    <div
      className="grid select-none gap-px bg-border-2 p-1 rounded-lg"
      style={{
        gridTemplateColumns: "20px repeat(10, minmax(0, 1fr))",
        gridTemplateRows: "20px repeat(10, minmax(0, 1fr))",
        width: "min(86vw, 420px)",
        aspectRatio: "11 / 11",
      }}
      onMouseLeave={onCellLeave}
    >
      <div />
      {Array.from({ length: BOARD_SIZE }).map((_, c) => (
        <div
          key={`col-${c}`}
          className="flex items-center justify-center text-[10px] font-bold tracking-widest text-text-dim"
        >
          {COLS[c]}
        </div>
      ))}
      {Array.from({ length: BOARD_SIZE }).map((_, r) => (
        <RowView
          key={`row-${r}`}
          r={r}
          board={board}
          mode={mode}
          showShips={showShips}
          sunkIds={sunkIds}
          previewSet={previewSet}
          previewValid={preview?.valid ?? false}
          onCellEnter={onCellEnter}
          onCellClick={onCellClick}
          skinIcons={skin.icons}
        />
      ))}
    </div>
  );
}

function RowView({
  r,
  board,
  mode,
  showShips,
  sunkIds,
  previewSet,
  previewValid,
  onCellEnter,
  onCellClick,
  skinIcons,
}: {
  r: number;
  board: Board;
  mode: BoardMode;
  showShips: boolean;
  sunkIds: Set<string>;
  previewSet: Set<string> | null;
  previewValid: boolean;
  onCellEnter?: (row: number, col: number) => void;
  onCellClick?: (row: number, col: number) => void;
  skinIcons: Record<ShipId, string | null>;
}) {
  return (
    <>
      <div className="flex items-center justify-center text-[10px] font-bold text-text-dim">
        {r + 1}
      </div>
      {board[r].map((cell, c) => {
        const isPreview = previewSet?.has(`${r}:${c}`);
        const isShip = showShips && cell.shipId;
        const isSunk = isShip && sunkIds.has(cell.shipId!);
        const targetable = mode === "target" && !cell.hit;
        const skinIcon = isShip && cell.shipId ? skinIcons[cell.shipId] : null;

        return (
          <button
            key={`${r}-${c}`}
            type="button"
            disabled={mode === "own" || (mode === "target" && cell.hit)}
            onMouseEnter={() => onCellEnter?.(r, c)}
            onClick={() => onCellClick?.(r, c)}
            className={cn(
              "relative flex aspect-square items-center justify-center rounded-sm text-xs transition",
              // base
              "bg-surface-2 border border-border",
              // ship
              isShip && !isSunk && "bg-ship border-accent",
              isShip && isSunk && "bg-ship-sunk border-hit",
              // hit/miss markers
              cell.hit && cell.shipId && "bg-hit border-hit animate-hit-pulse",
              cell.hit && !cell.shipId && "bg-surface-2",
              // preview
              isPreview && previewValid && "bg-green/40 border-green",
              isPreview && !previewValid && "bg-hit/40 border-hit",
              // hover for target mode
              targetable && "cursor-crosshair hover:bg-surface hover:border-accent hover:scale-110 z-10",
              !targetable && mode === "target" && "cursor-not-allowed opacity-60",
            )}
            aria-label={`${COLS[c]}${r + 1}${cell.hit ? (cell.shipId ? " hit" : " miss") : ""}`}
          >
            {cell.hit && cell.shipId && <span className="text-white font-black">✕</span>}
            {cell.hit && !cell.shipId && (
              <span className="size-1.5 rounded-full bg-miss" />
            )}
            {!cell.hit && skinIcon && (
              <span className="select-none text-base leading-none" aria-hidden>
                {skinIcon}
              </span>
            )}
          </button>
        );
      })}
    </>
  );
}
