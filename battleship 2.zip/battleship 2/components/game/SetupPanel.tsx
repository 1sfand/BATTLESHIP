"use client";

import { SHIP_DEFS } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";

interface Props {
  placingIndex: number;
  horizontal: boolean;
  onOrientation: (h: boolean) => void;
  onRandom: () => void;
  onConfirm: () => void;
}

export function SetupPanel({
  placingIndex,
  horizontal,
  onOrientation,
  onRandom,
  onConfirm,
}: Props) {
  const allPlaced = placingIndex >= SHIP_DEFS.length;
  const def = SHIP_DEFS[placingIndex];

  return (
    <div className="flex w-full max-w-[260px] flex-col gap-3">
      <div className="rounded-xl border border-border bg-surface p-4">
        <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
          Fleet
        </div>
        <div className="flex flex-col gap-1">
          {SHIP_DEFS.map((s, i) => (
            <div
              key={s.id}
              className={cn(
                "flex items-center justify-between rounded px-3 py-2 text-sm",
                i < placingIndex && "opacity-40",
                i === placingIndex && "bg-surface-2 ring-1 ring-accent",
              )}
            >
              <span className="font-medium">
                {i < placingIndex ? "✓ " : ""}
                {s.name}
              </span>
              <span className="text-xs text-text-dim">{s.size}</span>
            </div>
          ))}
        </div>
      </div>

      {!allPlaced && def && (
        <>
          <div className="rounded-xl border border-border bg-surface p-4">
            <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
              Orientation
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => onOrientation(true)}
                className={cn(
                  "flex-1 rounded-md border py-2 text-sm font-bold",
                  horizontal
                    ? "border-accent bg-accent text-white"
                    : "border-border bg-surface-2 text-text-dim",
                )}
              >
                → H
              </button>
              <button
                onClick={() => onOrientation(false)}
                className={cn(
                  "flex-1 rounded-md border py-2 text-sm font-bold",
                  !horizontal
                    ? "border-accent bg-accent text-white"
                    : "border-border bg-surface-2 text-text-dim",
                )}
              >
                ↓ V
              </button>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-text-dim">
              Hover to preview · Click to place{" "}
              <strong className="text-text">{def.name}</strong>
              <br />
              Press{" "}
              <kbd className="rounded bg-surface-2 px-1.5 py-0.5 text-[11px]">R</kbd>{" "}
              to rotate
            </p>
          </div>

          <button
            onClick={onRandom}
            className="rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium hover:border-accent"
          >
            🎲 Random Placement
          </button>
        </>
      )}

      {allPlaced && (
        <div className="rounded-xl border border-green bg-surface p-4">
          <div className="mb-2 text-sm font-bold text-green">
            ✓ All ships placed
          </div>
          <button
            onClick={onConfirm}
            className="w-full rounded-md bg-accent px-4 py-2 text-sm font-bold text-white hover:opacity-90"
          >
            Confirm Fleet →
          </button>
        </div>
      )}
    </div>
  );
}
