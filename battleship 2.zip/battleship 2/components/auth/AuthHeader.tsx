"use client";

import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { getSupabaseBrowser } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { LeagueBadge } from "@/components/league/LeagueBadge";

export function AuthHeader() {
  const { loading, user, profile, configured } = useAuth();
  const router = useRouter();

  if (!configured) {
    return (
      <Link
        href="/auth/sign-in"
        className="rounded-md border border-accent-2/40 bg-accent-2/10 px-3 py-1.5 text-xs font-medium text-accent-2 hover:bg-accent-2/20"
      >
        Set up cloud
      </Link>
    );
  }

  if (loading) return <div className="h-8 w-24 animate-pulse rounded-md bg-surface-2" />;

  if (!user) {
    return (
      <Link
        href="/auth/sign-in"
        className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-medium hover:border-accent"
      >
        Sign in
      </Link>
    );
  }

  const signOut = async () => {
    await getSupabaseBrowser()?.auth.signOut();
    router.refresh();
  };

  const isAnon = user.is_anonymous;
  const name = profile?.nickname ?? "Admiral";

  return (
    <div className="flex items-center gap-2">
      <Link
        href="/profile"
        className="flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1.5 text-xs font-medium hover:border-accent"
      >
        {profile?.avatar_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={profile.avatar_url} alt="" className="size-5 rounded-full" />
        ) : (
          <span className="grid size-5 place-items-center rounded-full bg-accent text-[10px] font-black text-white">
            {name[0]?.toUpperCase()}
          </span>
        )}
        <span>{name}</span>
        {isAnon && (
          <span className="rounded bg-accent-2/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-accent-2">
            guest
          </span>
        )}
        {profile && (
          <LeagueBadge rating={profile.rating} size="xs" showRating />
        )}
      </Link>
      <button
        onClick={signOut}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-xs text-text-dim hover:border-hit hover:text-hit"
        aria-label="Sign out"
      >
        ⏻
      </button>
    </div>
  );
}
