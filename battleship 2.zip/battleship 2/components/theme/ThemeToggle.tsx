"use client";

import { useThemeStore } from "@/stores/theme";
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const { theme, setTheme } = useThemeStore();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) return <div className="size-9" />;

  const next = theme === "dark" ? "light" : "dark";
  const icon = theme === "dark" ? "☀" : "☾";

  return (
    <button
      onClick={() => setTheme(next)}
      aria-label={`Switch to ${next} theme`}
      className="flex size-9 items-center justify-center rounded-lg border border-border bg-surface text-base hover:border-accent"
    >
      {icon}
    </button>
  );
}
