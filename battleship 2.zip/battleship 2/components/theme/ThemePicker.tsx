"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useThemeStore, type ThemeId } from "@/stores/theme";

interface ThemeMeta {
  id: ThemeId;
  name: string;
  swatch: { bg: string; surface: string; accent: string };
  pro: boolean;
}

const THEMES: ThemeMeta[] = [
  { id: "dark",   name: "Dark",   pro: false, swatch: { bg: "#0a1628", surface: "#142a54", accent: "#3a7bd5" } },
  { id: "light",  name: "Light",  pro: false, swatch: { bg: "#eef3fb", surface: "#ffffff", accent: "#1f4f9c" } },
  { id: "naval",  name: "Naval",  pro: true,  swatch: { bg: "#001b39", surface: "#003572", accent: "#ffd166" } },
  { id: "neon",   name: "Neon",   pro: true,  swatch: { bg: "#050010", surface: "#18003a", accent: "#ff00d4" } },
  { id: "retro",  name: "Retro",  pro: true,  swatch: { bg: "#f4ecd6", surface: "#ffefc7", accent: "#2856a8" } },
  { id: "paper",  name: "Paper",  pro: true,  swatch: { bg: "#fafaf6", surface: "#ffffff", accent: "#0a0a0a" } },
];

export function ThemePicker() {
  const { theme, setTheme, isUnlocked } = useThemeStore();
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => setMounted(true), []);

  // Close dropdown on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  if (!mounted) return <div className="size-9" />;

  const current = THEMES.find((t) => t.id === theme);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        aria-label="Pick a theme"
        className="flex size-9 items-center justify-center rounded-lg border border-border bg-surface text-base hover:border-accent"
        style={current ? { background: current.swatch.surface } : undefined}
      >
        🎨
      </button>

      {open && (
        <div className="absolute right-0 top-11 z-50 w-56 overflow-hidden rounded-xl border border-border bg-surface shadow-lg">
          <div className="border-b border-border bg-surface-2 px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
            Themes
          </div>
          <ul className="max-h-80 overflow-auto py-1">
            {THEMES.map((t) => {
              const unlocked = isUnlocked(t.id);
              const active = t.id === theme;
              return (
                <li key={t.id}>
                  <button
                    disabled={!unlocked}
                    onClick={() => {
                      if (unlocked) {
                        setTheme(t.id);
                        setOpen(false);
                      }
                    }}
                    className={`flex w-full items-center gap-3 px-3 py-2 text-left text-sm transition ${
                      active
                        ? "bg-accent/15 text-text"
                        : "hover:bg-surface-2"
                    } ${!unlocked ? "cursor-not-allowed opacity-50" : ""}`}
                  >
                    {/* swatch */}
                    <div
                      className="grid size-8 shrink-0 grid-cols-2 grid-rows-2 overflow-hidden rounded border border-border-2"
                      aria-hidden
                    >
                      <div style={{ background: t.swatch.bg }} />
                      <div style={{ background: t.swatch.accent }} />
                      <div style={{ background: t.swatch.surface }} />
                      <div style={{ background: t.swatch.bg }} />
                    </div>
                    <span className="flex-1 font-medium">{t.name}</span>
                    {active && <span className="text-accent">✓</span>}
                    {!unlocked && (
                      <span className="rounded bg-accent-2/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-accent-2">
                        Pro
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="border-t border-border bg-surface-2 px-3 py-2">
            <Link
              href="/upgrade"
              className="text-[11px] text-accent hover:underline"
              onClick={() => setOpen(false)}
            >
              👑 Unlock all themes →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
