"use client";

import { useEffect } from "react";
import { useThemeStore } from "@/stores/theme";

/**
 * Applies the current theme by setting `data-theme` AND a class on <html>.
 * Doubling up gives us two CSS hooks in case something interferes.
 */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = useThemeStore((s) => s.theme);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = theme;
    // Also set a class so CSS rules with class selectors work as a fallback
    const themes = ["dark", "light", "naval", "neon", "retro", "paper"];
    themes.forEach((t) => root.classList.remove(`theme-${t}`));
    root.classList.add(`theme-${theme}`);
    // Force a visible style recompute (some browsers cache aggressively)
    root.style.colorScheme = theme === "light" ? "light" : "dark";
  }, [theme]);

  return <>{children}</>;
}
