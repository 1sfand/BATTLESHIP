"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabaseBrowser } from "@/lib/supabase/client";
import { LeagueBadge } from "@/components/league/LeagueBadge";
import { useAuth } from "@/hooks/useAuth";

function generateRoomCode(): string {
  // 6-char A-Z2-9 (no 0/O/1/I/L confusion)
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return s;
}

export function OnlineLobby() {
  const router = useRouter();
  const { profile } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");

  // Quick-match polling state
  const [searching, setSearching] = useState(false);
  const [searchSeconds, setSearchSeconds] = useState(0);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const supabase = getSupabaseBrowser();

  // Quick match — atomic match-or-queue function
  const startQuickMatch = async () => {
    if (!supabase) return;
    setSearching(true);
    setError(null);
    setSearchSeconds(0);
    tickRef.current = setInterval(() => setSearchSeconds((s) => s + 1), 1000);

    const tryMatch = async () => {
      const { data, error } = await supabase.rpc("find_or_create_match");
      if (error) {
        cancelQuickMatch();
        setError(error.message);
        return;
      }
      const roomId = data as string | null;
      if (roomId) {
        cancelQuickMatch();
        router.push(`/play/online/${roomId}`);
      }
    };

    await tryMatch();
    pollRef.current = setInterval(tryMatch, 2500);
  };

  const cancelQuickMatch = () => {
    if (pollRef.current) clearInterval(pollRef.current);
    if (tickRef.current) clearInterval(tickRef.current);
    pollRef.current = null;
    tickRef.current = null;
    setSearching(false);
    if (supabase) void supabase.rpc("leave_matchmaking");
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => cancelQuickMatch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!supabase) return null;

  const createRoom = async () => {
    setBusy(true); setError(null);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setError("Not signed in"); setBusy(false); return; }

    const code = generateRoomCode();
    const { data, error } = await supabase
      .from("online_rooms")
      .insert({ code, host_id: user.id, phase: "lobby" })
      .select("id")
      .single();
    setBusy(false);
    if (error) {
      console.error("[createRoom] insert error:", error);
      setError(`${error.message} (code ${error.code ?? "?"})`);
      return;
    }
    if (!data) { setError("Failed to create room"); return; }
    router.push(`/play/online/${(data as { id: string }).id}`);
  };

  const joinRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setError(null);
    const code = joinCode.trim().toUpperCase();
    if (code.length !== 6) { setError("Code must be 6 characters"); setBusy(false); return; }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setError("Not signed in"); setBusy(false); return; }

    const { data: room, error } = await supabase
      .from("online_rooms")
      .select("id, host_id, guest_id")
      .eq("code", code)
      .maybeSingle();
    if (error || !room) { setError("Room not found"); setBusy(false); return; }
    const r = room as { id: string; host_id: string; guest_id: string | null };

    // Already host? just navigate
    if (r.host_id === user.id) {
      setBusy(false);
      router.push(`/play/online/${r.id}`);
      return;
    }

    // Take the guest seat if open
    if (!r.guest_id) {
      await supabase.from("online_rooms").update({ guest_id: user.id }).eq("id", r.id);
    } else if (r.guest_id !== user.id) {
      setError("Room is full");
      setBusy(false);
      return;
    }
    setBusy(false);
    router.push(`/play/online/${r.id}`);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Quick Match — primary CTA */}
      {searching ? (
        <div className="rounded-xl border border-accent bg-surface p-6 text-center">
          <div className="mb-3 flex items-center justify-center gap-2 text-lg font-bold">
            <span className="inline-block size-3 animate-pulse rounded-full bg-accent" />
            Searching for opponent…
          </div>
          {profile && (
            <p className="mb-3 text-xs text-text-dim">
              Matching in <LeagueBadge rating={profile.rating} size="xs" /> within ±200 ELO
            </p>
          )}
          <p className="mb-4 text-2xl font-mono font-bold tabular-nums">
            {Math.floor(searchSeconds / 60)}:{String(searchSeconds % 60).padStart(2, "0")}
          </p>
          <button
            onClick={cancelQuickMatch}
            className="rounded-md border border-hit bg-hit/10 px-4 py-2 text-xs font-bold text-hit hover:bg-hit/20"
          >
            Cancel search
          </button>
        </div>
      ) : (
        <button
          onClick={startQuickMatch}
          disabled={busy}
          className="rounded-xl border border-accent bg-gradient-to-br from-accent/20 to-transparent p-6 text-left transition hover:from-accent/30 disabled:opacity-50"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-bold">⚡ Quick Match</div>
              <p className="mt-1 text-xs text-text-dim">
                Find a random opponent in your league.
              </p>
            </div>
            {profile && <LeagueBadge rating={profile.rating} size="xs" />}
          </div>
        </button>
      )}

      <button
        onClick={createRoom}
        disabled={busy || searching}
        className="rounded-xl border border-border bg-surface px-6 py-5 text-left transition hover:bg-surface-2 disabled:opacity-50"
      >
        <div className="text-lg font-bold">⚡ Private room</div>
        <p className="mt-1 text-xs text-text-dim">
          Create a 6-letter code to share with a specific friend.
        </p>
      </button>

      <div className="flex items-center gap-3 text-[10px] uppercase tracking-widest text-text-dim">
        <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
      </div>

      <form onSubmit={joinRoom} className="rounded-xl border border-border bg-surface p-5">
        <div className="text-lg font-bold">🚪 Join room</div>
        <p className="mt-1 text-xs text-text-dim">Enter the code your friend shared.</p>
        <input
          type="text"
          maxLength={6}
          value={joinCode}
          onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
          placeholder="ABC123"
          className="mt-3 w-full rounded-md border border-border bg-surface-2 px-3 py-2 text-center text-lg font-mono tracking-[.5em] uppercase outline-none focus:border-accent"
        />
        <button
          type="submit"
          disabled={busy || joinCode.length !== 6}
          className="mt-3 w-full rounded-md bg-accent px-4 py-2 text-sm font-bold text-white hover:opacity-90 disabled:opacity-50"
        >
          Join →
        </button>
      </form>

      {error && <p className="text-sm text-hit">{error}</p>}
    </div>
  );
}
