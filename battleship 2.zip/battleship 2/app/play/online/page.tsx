import Link from "next/link";
import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { OnlineLobby } from "./OnlineLobby";

export const metadata = { title: "Online · Battleship" };

export default async function OnlineLobbyPage() {
  if (!isSupabaseConfigured()) return <NotConfigured />;

  const supabase = await getSupabaseServer();
  if (!supabase) return <NotConfigured />;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth/sign-in?next=/play/online");

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-6 py-12">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-md">
        <h1 className="title-gradient mb-1 text-3xl font-black uppercase tracking-wider text-center">
          🌐 Online
        </h1>
        <p className="mb-6 text-center text-sm text-text-dim">
          Create a room and share the code, or join with a friend&apos;s code.
        </p>

        <OnlineLobby />
      </div>
    </main>
  );
}

function NotConfigured() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <div className="max-w-md rounded-2xl border border-border bg-surface p-8 text-center">
        <p className="text-text-dim">
          Online play needs cloud setup. Add Supabase env vars and run the migrations.
        </p>
        <Link href="/" className="mt-4 inline-block text-accent hover:underline">← Back home</Link>
      </div>
    </main>
  );
}
