import Link from "next/link";
import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { OnlineRoom } from "./OnlineRoom";

export const metadata = { title: "Online room · Battleship" };

interface Props { params: Promise<{ id: string }> }

export default async function OnlineRoomPage({ params }: Props) {
  const { id } = await params;

  if (!isSupabaseConfigured()) return <NotConfigured />;
  const supabase = await getSupabaseServer();
  if (!supabase) return <NotConfigured />;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/auth/sign-in?next=/play/online/${id}`);

  // Don't 404 server-side — let the client component fetch and report.
  // Server-side RLS may be slightly behind the just-created room (cache lag).
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-8">
      <Link href="/play/online" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Lobby
      </Link>
      <OnlineRoom roomId={id} userId={user.id} />
    </main>
  );
}

function NotConfigured() {
  return (
    <main className="flex flex-1 items-center justify-center p-8">
      <p className="text-text-dim">Online play needs cloud setup.</p>
    </main>
  );
}
