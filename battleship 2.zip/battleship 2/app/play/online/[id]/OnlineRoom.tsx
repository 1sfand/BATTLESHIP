"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Board } from "@/components/game/Board";
import { FleetStatus } from "@/components/game/FleetStatus";
import { SetupPanel } from "@/components/game/SetupPanel";
import { getSupabaseBrowser } from "@/lib/supabase/client";
import {
  COLS,
  SHIP_DEFS,
  censorBoard,
  createBoard,
  fireAt,
  getPositions,
  isFleetDestroyed,
  isValidPlacement,
  placeShipOnBoard,
  randomPlacement,
} from "@/lib/engine";
import type { Board as BoardT, Move, PlacedShip, Position } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";

type Phase = "lobby" | "setup" | "battle" | "gameover";

interface Room {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  phase: Phase;
  turn: number;        // 0 = host, 1 = guest
  host_state: { ships: { id: string; positions: Position[] }[] } | null;
  guest_state: { ships: { id: string; positions: Position[] }[] } | null;
  moves: Move[];
  winner: number | null;
}

/**
 * Online 1v1 room. Each side renders its own ships locally; the server only
 * knows ship placements to validate fairness and reconstruct on reconnect.
 *
 * Move broadcast: each shot is appended to `online_rooms.moves` as a JSON
 * array. We subscribe to row UPDATEs via Supabase Realtime to apply opponent
 * moves on our side.
 */
export function OnlineRoom({ roomId, userId }: { roomId: string; userId: string }) {
  const supabase = getSupabaseBrowser();
  const [room, setRoom] = useState<Room | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isHost = room ? room.host_id === userId : false;
  const mySide: 0 | 1 = isHost ? 0 : 1;
  const oppSide: 0 | 1 = (mySide ^ 1) as 0 | 1;

  // ── Local board state (your own ships + opponent's hits on you) ─────────
  const [myBoard, setMyBoard] = useState<BoardT>(createBoard());
  const [myShips, setMyShips] = useState<PlacedShip[]>([]);

  // ── Opponent board (only what we've shot) ───────────────────────────────
  const [oppBoard, setOppBoard] = useState<BoardT>(createBoard());
  const [oppShips, setOppShips] = useState<PlacedShip[]>([]);

  // ── Setup state ─────────────────────────────────────────────────────────
  const [placingIndex, setPlacingIndex] = useState(0);
  const [horizontal, setHorizontal] = useState(true);
  const [hover, setHover] = useState<{ row: number; col: number } | null>(null);
  const [submitted, setSubmitted] = useState(false);

  // ── Subscribe to room updates ───────────────────────────────────────────
  useEffect(() => {
    if (!supabase) return;
    let ignore = false;

    const fetchRoom = async (attempt = 1): Promise<void> => {
      const { data, error } = await supabase
        .from("online_rooms")
        .select("*")
        .eq("id", roomId)
        .maybeSingle();
      if (ignore) return;

      if (error) {
        console.error("[OnlineRoom] fetch error:", error);
        setError(`Database error: ${error.message} (code ${error.code ?? "?"})`);
        return;
      }

      if (!data) {
        // RLS may briefly return empty for a freshly-inserted row before
        // postgrest's schema cache catches up. Retry up to 3× with backoff.
        if (attempt < 3) {
          setTimeout(() => fetchRoom(attempt + 1), 400 * attempt);
          return;
        }
        // Diagnostic: also try to confirm the user is signed in
        const { data: { user } } = await supabase.auth.getUser();
        setError(
          user
            ? `Room ${roomId.slice(0, 8)}… not visible to you. You may not be a participant (RLS blocked).`
            : "Not signed in. Refresh the page and sign in again.",
        );
        return;
      }
      setRoom(data as Room);
    };
    fetchRoom();

    const channel = supabase
      .channel(`room:${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "online_rooms",
          filter: `id=eq.${roomId}`,
        },
        (payload: { new: Room }) => setRoom(payload.new),
      )
      .subscribe();

    return () => {
      ignore = true;
      supabase.removeChannel(channel);
    };
  }, [supabase, roomId]);

  // ── React to room phase changes ─────────────────────────────────────────
  useEffect(() => {
    if (!room) return;
    if (room.phase !== "battle") return;
    // Once battle starts, reconstruct local boards from initial states + moves.
    const myInitial = mySide === 0 ? room.host_state : room.guest_state;
    const oppInitial = mySide === 0 ? room.guest_state : room.host_state;
    if (myInitial) reconstructLocal(myInitial);
    if (oppInitial) reconstructOpponent(oppInitial);
    applyAllMoves(room.moves);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room?.phase, room?.host_state, room?.guest_state]);

  // Apply each move to the appropriate board
  useEffect(() => {
    if (!room || room.phase !== "battle") return;
    applyAllMoves(room.moves);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room?.moves?.length]);

  function reconstructLocal(state: NonNullable<Room["host_state"]>) {
    let board = createBoard();
    const ships: PlacedShip[] = [];
    for (const s of state.ships) {
      const def = SHIP_DEFS.find((d) => d.id === s.id);
      if (!def) continue;
      board = placeShipOnBoard(board, def.id, s.positions);
      ships.push({ id: def.id, name: def.name, size: def.size, positions: s.positions, sunk: false });
    }
    setMyBoard(board);
    setMyShips(ships);
  }

  function reconstructOpponent(state: NonNullable<Room["host_state"]>) {
    // We only know ship sizes; positions stay hidden until hit.
    const ships: PlacedShip[] = state.ships.map((s) => {
      const def = SHIP_DEFS.find((d) => d.id === s.id)!;
      return { id: def.id, name: def.name, size: def.size, positions: s.positions, sunk: false };
    });
    setOppShips(ships);
    setOppBoard(createBoard());
  }

  function applyAllMoves(moves: Move[]) {
    if (!moves || moves.length === 0) return;
    // Re-derive boards from scratch using initial states + all moves (idempotent)
    const myInit = mySide === 0 ? room?.host_state : room?.guest_state;
    const oppInit = mySide === 0 ? room?.guest_state : room?.host_state;
    if (!myInit || !oppInit) return;

    let mb = buildBoard(myInit.ships);
    let ms = buildShips(myInit.ships);
    let ob = createBoard();
    let os = buildShips(oppInit.ships);

    for (const m of moves) {
      if (m.type !== "shot") continue;
      if (m.attacker === mySide) {
        // I shot at opp board
        const r = fireAt(ob, os, m.row, m.col);
        if (r) { ob = r.board; os = r.ships; }
        // Reveal sunk ship positions on opp board for FleetStatus rendering
      } else {
        // Opponent shot at my board
        const r = fireAt(mb, ms, m.row, m.col);
        if (r) { mb = r.board; ms = r.ships; }
      }
    }

    setMyBoard(mb);
    setMyShips(ms);
    setOppBoard(ob);
    setOppShips(os);
  }

  // ── Setup actions ───────────────────────────────────────────────────────
  const placeAt = (row: number, col: number) => {
    if (placingIndex >= SHIP_DEFS.length) return;
    const def = SHIP_DEFS[placingIndex];
    const positions = getPositions(row, col, def.size, horizontal);
    if (!isValidPlacement(myBoard, positions)) return;
    setMyBoard(placeShipOnBoard(myBoard, def.id, positions));
    setMyShips([...myShips, { id: def.id, name: def.name, size: def.size, positions, sunk: false }]);
    setPlacingIndex(placingIndex + 1);
  };

  const randomize = () => {
    let r = randomPlacement();
    for (let i = 0; i < 10 && !r; i++) r = randomPlacement();
    if (!r) return;
    setMyBoard(r.board);
    setMyShips(r.ships);
    setPlacingIndex(SHIP_DEFS.length);
  };

  const submitFleet = async () => {
    if (!supabase || !room) return;
    const payload = { ships: myShips.map((s) => ({ id: s.id, positions: s.positions })) };
    const update = isHost ? { host_state: payload } : { guest_state: payload };
    await supabase.from("online_rooms").update(update).eq("id", roomId);
    setSubmitted(true);

    // If both sides have submitted, transition to battle
    const { data: latest } = await supabase
      .from("online_rooms")
      .select("host_state, guest_state, phase")
      .eq("id", roomId)
      .maybeSingle();
    const l = latest as { host_state: unknown; guest_state: unknown; phase: string } | null;
    if (l && l.host_state && l.guest_state && l.phase !== "battle") {
      await supabase.from("online_rooms").update({ phase: "battle", turn: 0 }).eq("id", roomId);
    }
  };

  const startSetup = async () => {
    if (!supabase || !room || !isHost) return;
    if (!room.guest_id) { setError("Waiting for opponent to join"); return; }
    await supabase.from("online_rooms").update({ phase: "setup" }).eq("id", roomId);
  };

  // ── Battle action ───────────────────────────────────────────────────────
  const fireAtCell = async (row: number, col: number) => {
    if (!supabase || !room || room.phase !== "battle") return;
    if (room.turn !== mySide) return;
    if (oppBoard[row][col].hit) return;

    // Determine hit by checking opp ships (we know positions for sync)
    const oppInit = mySide === 0 ? room.guest_state : room.host_state;
    if (!oppInit) return;
    const ships = buildShips(oppInit.ships);
    let board = createBoard();
    // Replay moves to get current state
    for (const m of room.moves) {
      if (m.type !== "shot" || m.attacker !== mySide) continue;
      const r = fireAt(board, ships, m.row, m.col);
      if (r) { board = r.board; }
    }
    const result = fireAt(board, ships, row, col);
    if (!result) return;

    const newMove: Move = {
      type: "shot",
      attacker: mySide,
      row,
      col,
      hit: result.hit,
      sunkShipId: result.sunkShip?.id ?? null,
      ts: Date.now(),
    };

    const allHits = [...room.moves.filter((m) => m.type === "shot" && m.attacker === mySide), newMove];
    let probe = createBoard();
    let probeShips = buildShips(oppInit.ships);
    for (const m of allHits) {
      const r = fireAt(probe, probeShips, m.row, m.col);
      if (r) { probe = r.board; probeShips = r.ships; }
    }
    const won = isFleetDestroyed(probeShips);

    await supabase
      .from("online_rooms")
      .update({
        moves: [...room.moves, newMove],
        turn: won ? room.turn : oppSide,
        phase: won ? "gameover" : "battle",
        winner: won ? mySide : null,
      })
      .eq("id", roomId);
  };

  // ── Setup preview ───────────────────────────────────────────────────────
  const preview = useMemo(() => {
    if (!hover) return null;
    if (placingIndex >= SHIP_DEFS.length) return null;
    const def = SHIP_DEFS[placingIndex];
    const positions = getPositions(hover.row, hover.col, def.size, horizontal);
    return { positions: positions as [number, number][], valid: isValidPlacement(myBoard, positions) };
  }, [hover, horizontal, placingIndex, myBoard]);

  // Keyboard rotate
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key.toLowerCase() === "r") setHorizontal((h) => !h); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // ── Render ──────────────────────────────────────────────────────────────
  if (error) return <div className="text-sm text-hit">{error}</div>;
  if (!room) return <div className="text-text-dim">Loading room…</div>;

  if (room.phase === "lobby") {
    return (
      <div className="flex w-full max-w-md flex-col items-center gap-4 text-center">
        <h2 className="title-gradient text-2xl font-black uppercase tracking-wider">
          Room {room.code}
        </h2>
        <p className="text-sm text-text-dim">
          Share this code with a friend, then start when they&apos;ve joined.
        </p>
        <div className="rounded-xl border border-accent bg-surface px-8 py-6 text-3xl font-mono tracking-[.5em]">
          {room.code}
        </div>
        <button
          onClick={() => navigator.clipboard?.writeText(`${window.location.origin}/play/online?join=${room.code}`)}
          className="text-xs text-accent hover:underline"
        >
          Copy invite link
        </button>
        <p className="text-xs text-text-dim">
          {room.guest_id ? "✓ Opponent connected" : "Waiting for opponent…"}
        </p>
        {isHost && (
          <button
            onClick={startSetup}
            disabled={!room.guest_id}
            className="mt-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-white hover:opacity-90 disabled:opacity-50"
          >
            Start setup →
          </button>
        )}
      </div>
    );
  }

  if (room.phase === "setup") {
    const myDone =
      submitted ||
      (mySide === 0 ? !!room.host_state : !!room.guest_state);
    const theyDone = mySide === 0 ? !!room.guest_state : !!room.host_state;

    return (
      <div className="flex w-full max-w-5xl flex-col items-center gap-6 md:flex-row md:items-start md:justify-center">
        <SetupPanel
          placingIndex={placingIndex}
          horizontal={horizontal}
          onOrientation={setHorizontal}
          onRandom={randomize}
          onConfirm={submitFleet}
        />
        <div className="flex flex-col items-center gap-3">
          <div className="rounded-full border border-accent bg-surface px-4 py-1 text-xs font-bold uppercase tracking-wider text-accent">
            ⚓ Place your fleet
          </div>
          {!myDone ? (
            <Board
              board={myBoard}
              ships={myShips}
              mode="setup"
              preview={preview}
              onCellEnter={(row, col) => setHover({ row, col })}
              onCellLeave={() => setHover(null)}
              onCellClick={(row, col) => placeAt(row, col)}
            />
          ) : (
            <div className="rounded-xl border border-green/50 bg-surface p-6 text-center">
              <p className="text-lg font-bold text-green">✓ Fleet locked in</p>
              <p className="mt-1 text-xs text-text-dim">
                {theyDone ? "Both ready — starting battle…" : "Waiting for opponent…"}
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (room.phase === "battle" || room.phase === "gameover") {
    const myTurn = room.turn === mySide;
    const lastMove = room.moves[room.moves.length - 1];
    const status =
      room.phase === "gameover"
        ? room.winner === mySide
          ? { msg: "🏆 Victory! Fleet destroyed.", cls: "border-green text-green" }
          : { msg: "💥 Defeated. Better luck next round.", cls: "border-hit text-hit" }
        : myTurn
          ? { msg: "⚔ Your turn — pick a target", cls: "border-accent text-accent" }
          : { msg: "⏳ Opponent is targeting…", cls: "border-border text-text-dim" };

    return (
      <div className="flex w-full max-w-5xl flex-col items-center gap-5">
        <div className="flex flex-wrap items-center justify-center gap-3">
          <div className="rounded-full bg-gradient-to-r from-accent to-blue-700 px-4 py-1 text-sm font-bold text-white">
            Room {room.code}
          </div>
          <div className={cn("min-w-[280px] rounded-md border bg-surface px-4 py-2 text-center text-sm font-medium", status.cls)}>
            {status.msg}
          </div>
        </div>

        {lastMove && lastMove.attacker !== mySide && room.phase === "battle" && (
          <p className="text-xs text-text-dim">
            They fired at <strong className="text-text">{COLS[lastMove.col]}{lastMove.row + 1}</strong> · {lastMove.hit ? (lastMove.sunkShipId ? "💥 SUNK" : "🎯 hit") : "💧 miss"}
          </p>
        )}

        <div className="flex flex-col items-start justify-center gap-8 md:flex-row">
          <div className="flex flex-col items-center gap-2">
            <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">Your waters</div>
            <Board board={myBoard} ships={myShips} mode="own" />
            <FleetStatus ships={myShips} board={myBoard} />
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">Enemy waters</div>
            <Board
              board={censorBoard(oppBoard)}
              ships={oppShips}
              mode="target"
              onCellClick={(r, c) => myTurn && room.phase === "battle" && fireAtCell(r, c)}
            />
            <FleetStatus ships={oppShips} board={censorBoard(oppBoard)} hideIntact />
          </div>
        </div>
      </div>
    );
  }

  return null;
}

// ── helpers ─────────────────────────────────────────────────────────────────
function buildBoard(stateShips: { id: string; positions: Position[] }[]): BoardT {
  let b = createBoard();
  for (const s of stateShips) {
    const def = SHIP_DEFS.find((d) => d.id === s.id);
    if (def) b = placeShipOnBoard(b, def.id, s.positions);
  }
  return b;
}

function buildShips(stateShips: { id: string; positions: Position[] }[]): PlacedShip[] {
  return stateShips.map((s) => {
    const def = SHIP_DEFS.find((d) => d.id === s.id)!;
    return { id: def.id, name: def.name, size: def.size, positions: s.positions, sunk: false };
  });
}
