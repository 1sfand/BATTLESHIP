import { GameView } from "@/components/game/GameView";

export default function BotPlayPage() {
  return <GameView mode="bot" />;
}
