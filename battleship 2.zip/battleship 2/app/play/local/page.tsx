import { GameView } from "@/components/game/GameView";

export default function LocalPlayPage() {
  return <GameView mode="local" />;
}
