import Link from "next/link";
import { SHIP_DEFS } from "@/lib/engine";
import { ThemePicker } from "@/components/theme/ThemePicker";
import { SkinPicker } from "@/components/skin/SkinPicker";
import { AuthHeader } from "@/components/auth/AuthHeader";
import { Onboarding } from "@/components/onboarding/Onboarding";
import { TutorialReplayButton } from "@/components/onboarding/TutorialReplayButton";

export default function HomePage() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <Onboarding />
      <div className="absolute right-6 top-6 flex items-center gap-2">
        <AuthHeader />
        <SkinPicker />
        <ThemePicker />
      </div>

      <div className="mb-2 text-center">
        <h1 className="title-gradient text-5xl font-black uppercase tracking-wider md:text-7xl">
          ⚓ Battleship
        </h1>
        <p className="mt-2 text-xs uppercase tracking-[.25em] text-text-dim">
          Naval Strategy · Story · Ranked
        </p>
      </div>

      <div className="mt-10 grid w-full max-w-3xl grid-cols-1 gap-4 md:grid-cols-2">
        <ModeCard
          title="Vs Bot"
          desc="Three difficulty levels. Quick match against the AI."
          href="/play/bot"
          icon="🤖"
          accent
        />
        <ModeCard
          title="Local 2-Player"
          desc="Hot-seat. Pass the device between turns."
          href="/play/local"
          icon="👥"
        />
        <ModeCard
          title="Story Mode"
          desc="Campaign with named admirals. Unlocks themes."
          href="/story"
          icon="📜"
        />
        <ModeCard
          title="Online"
          desc="Invite a friend with a link. Realtime."
          href="/play/online"
          icon="🌐"
        />
      </div>

      <div className="mt-12 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-text-dim">
        <Link href="/leaderboard" className="hover:text-accent">🏆 Leaderboard</Link>
        <Link href="/stats" className="hover:text-accent">📊 My Stats</Link>
        <Link href="/profile" className="hover:text-accent">👤 Profile</Link>
        <Link href="/academy" className="hover:text-accent">🏛 Academy</Link>
        <Link href="/upgrade" className="text-accent-2 hover:opacity-80">👑 Pass</Link>
        <TutorialReplayButton />
      </div>

      <FleetPreview />
    </main>
  );
}

function ModeCard({
  title,
  desc,
  href,
  icon,
  accent,
  locked,
}: {
  title: string;
  desc: string;
  href: string;
  icon: string;
  accent?: boolean;
  locked?: string;
}) {
  const baseClass =
    "group block rounded-xl border p-6 transition hover:-translate-y-0.5";
  const live = `${baseClass} border-border bg-surface hover:border-accent`;
  const accentCls = `${baseClass} border-accent bg-surface hover:bg-surface-2`;
  const lockedCls = `${baseClass} cursor-not-allowed border-border bg-surface opacity-50`;

  const content = (
    <>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-3xl">{icon}</span>
        {locked && (
          <span className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
            {locked}
          </span>
        )}
      </div>
      <h2 className="text-xl font-bold">{title}</h2>
      <p className="mt-1 text-sm text-text-dim">{desc}</p>
    </>
  );

  if (locked) return <div className={lockedCls}>{content}</div>;
  return (
    <Link href={href} className={accent ? accentCls : live}>
      {content}
    </Link>
  );
}

function FleetPreview() {
  return (
    <div className="mt-10 flex flex-col items-center gap-1 text-xs text-text-dim">
      <div className="mb-1 uppercase tracking-widest">Fleet</div>
      <div className="flex flex-col gap-1">
        {SHIP_DEFS.map((s) => (
          <div key={s.id} className="flex items-center gap-2">
            <span className="w-20 text-right">{s.name}</span>
            <div className="flex gap-px">
              {Array.from({ length: s.size }).map((_, i) => (
                <div
                  key={i}
                  className="size-3 rounded-sm border border-accent bg-ship"
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
