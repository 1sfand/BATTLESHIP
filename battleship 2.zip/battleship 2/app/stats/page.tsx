import Link from "next/link";
import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";

export const metadata = { title: "My Stats · Battleship" };

export default async function StatsPage() {
  if (!isSupabaseConfigured()) return <NotConfigured />;

  const supabase = await getSupabaseServer();
  if (!supabase) return <NotConfigured />;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth/sign-in?next=/stats");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  // Recent games
  const { data: games } = await supabase
    .from("games")
    .select("id, mode, difficulty, winner_id, created_at, ended_at, story_chapter")
    .or(`player1_id.eq.${user.id},player2_id.eq.${user.id}`)
    .order("created_at", { ascending: false })
    .limit(20);

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>
      <div className="w-full max-w-3xl">
        <h1 className="title-gradient mb-1 text-3xl font-black uppercase tracking-wider">
          📊 My Stats
        </h1>
        <p className="mb-8 text-sm text-text-dim">Your battles and accuracy at a glance.</p>

        {profile && (
          <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat label="Rating" value={profile.rating} />
            <Stat label="Wins" value={profile.wins} />
            <Stat label="Losses" value={profile.losses} />
            <Stat
              label="Accuracy"
              value={profile.shots > 0 ? `${Math.round((profile.hits / profile.shots) * 100)}%` : "—"}
            />
          </div>
        )}

        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-text-dim">
          Recent battles
        </h2>
        {(!games || games.length === 0) && (
          <p className="rounded-xl border border-border bg-surface p-8 text-center text-text-dim">
            No battles yet. <Link href="/play/bot" className="text-accent hover:underline">Start one</Link>.
          </p>
        )}
        {games && games.length > 0 && (
          <ul className="overflow-hidden rounded-xl border border-border bg-surface">
            {games.map((g) => {
              const won = g.winner_id === user.id;
              return (
                <li
                  key={g.id}
                  className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 text-sm last:border-b-0"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                          won ? "bg-green/20 text-green" : "bg-hit/20 text-hit"
                        }`}
                      >
                        {won ? "Win" : "Loss"}
                      </span>
                      <span className="text-text-dim">
                        {g.mode}
                        {g.difficulty && ` · ${g.difficulty}`}
                        {g.story_chapter && ` · ch. ${g.story_chapter}`}
                      </span>
                    </div>
                    <div className="mt-0.5 text-[11px] text-text-dim">
                      {new Date(g.created_at).toLocaleString()}
                    </div>
                  </div>
                  <Link
                    href={`/replay/${g.id}`}
                    className="text-xs text-accent hover:underline"
                  >
                    Replay →
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-lg border border-border bg-surface p-3">
      <div className="text-2xl font-black text-accent">{value}</div>
      <div className="text-[10px] uppercase tracking-widest text-text-dim">{label}</div>
    </div>
  );
}

function NotConfigured() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <div className="max-w-md rounded-2xl border border-border bg-surface p-8 text-center">
        <p className="text-text-dim">
          Cloud features aren&apos;t configured. Set up Supabase to track stats across devices.
        </p>
        <Link href="/" className="mt-4 inline-block text-accent hover:underline">← Back home</Link>
      </div>
    </main>
  );
}
