import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme/ThemeProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Battleship — Naval Strategy",
  description:
    "Classic Battleship with a story mode, AI advisor, and global ELO ranking.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${geistSans.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <ThemeProvider>
          <WaveBackground />
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}

function WaveBackground() {
  return (
    <div className="wave-bg" aria-hidden>
      <svg viewBox="0 0 1440 140" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M0,70 C240,110 480,30 720,70 C960,110 1200,30 1440,70 L1440,140 L0,140 Z"
          fill="#3a7bd5"
        />
        <path
          d="M0,90 C360,50 720,110 1080,70 C1260,50 1380,90 1440,80 L1440,140 L0,140 Z"
          fill="#2a5fb0"
          opacity=".6"
        />
      </svg>
    </div>
  );
}
