import Link from "next/link";
import { SKINS } from "@/lib/skins/skins";

export const metadata = { title: "Admiral's Pass · Battleship" };

const FEATURES = [
  { icon: "🎨", title: "All themes", desc: "Naval, Neon, Retro, Paper, Crimson Tide, Submarine Yellow." },
  { icon: "🏛", title: "Naval Academy", desc: "Step-by-step tutorials on probability targeting, opening theory, fleet placement." },
  { icon: "🚢", title: "Premium ship skins", desc: "Animated ship sprites, custom hit effects, signature emblems." },
  { icon: "📊", title: "Advanced stats", desc: "Heatmaps of your shooting, opening repertoire, win-rate by league." },
  { icon: "🤖", title: "Unlimited AI advisor", desc: "Replay commentary on every move, deeper analysis with Gemini Pro." },
  { icon: "👑", title: "Profile flair", desc: "Animated avatars, custom titles, exclusive admiral portraits." },
];

const PLANS = [
  {
    id: "monthly",
    name: "Monthly",
    price: "$2.99",
    cadence: "/ month",
    cta: "Subscribe — Coming Soon",
    highlight: false,
  },
  {
    id: "yearly",
    name: "Yearly",
    price: "$24.99",
    cadence: "/ year",
    badge: "Save 30%",
    cta: "Subscribe — Coming Soon",
    highlight: true,
  },
  {
    id: "lifetime",
    name: "Lifetime",
    price: "$59",
    cadence: "one-time",
    badge: "Best value",
    cta: "Buy — Coming Soon",
    highlight: false,
  },
];

export default function UpgradePage() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-4xl">
        <div className="mb-10 text-center">
          <span className="rounded-full border border-accent-2 bg-accent-2/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-accent-2">
            👑 Admiral's Pass
          </span>
          <h1 className="title-gradient mt-3 text-4xl font-black uppercase tracking-wider md:text-5xl">
            Command the Fleet
          </h1>
          <p className="mt-2 text-sm text-text-dim">
            Unlock every theme, every skin, and the Naval Academy.
            <br />Support development of the game you actually want.
          </p>
        </div>

        {/* Features grid */}
        <div className="mb-12 grid gap-3 md:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-xl border border-border bg-surface p-5">
              <div className="text-2xl">{f.icon}</div>
              <h3 className="mt-2 font-bold">{f.title}</h3>
              <p className="mt-1 text-xs text-text-dim">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="grid gap-4 md:grid-cols-3">
          {PLANS.map((p) => (
            <div
              key={p.id}
              className={`rounded-2xl border p-6 ${
                p.highlight
                  ? "border-accent-2 bg-gradient-to-br from-accent-2/10 to-transparent shadow-[0_0_40px_-10px_rgba(244,162,97,0.4)]"
                  : "border-border bg-surface"
              }`}
            >
              {p.badge && (
                <span className="inline-block rounded-full bg-accent-2 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-bg">
                  {p.badge}
                </span>
              )}
              <h3 className="mt-2 text-xl font-bold">{p.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-black">{p.price}</span>
                <span className="text-xs text-text-dim">{p.cadence}</span>
              </div>
              <button
                disabled
                className={`mt-6 w-full rounded-md py-2.5 text-sm font-bold ${
                  p.highlight
                    ? "bg-accent-2 text-bg"
                    : "border border-border bg-surface-2 text-text-dim"
                } opacity-70`}
              >
                {p.cta}
              </button>
              <p className="mt-2 text-center text-[10px] text-text-dim">
                Stripe / Paddle integration arrives soon.
              </p>
            </div>
          ))}
        </div>

        {/* Skin showcase */}
        <div className="mt-12">
          <h2 className="mb-4 text-center text-[10px] font-bold uppercase tracking-widest text-text-dim">
            Ship Skins
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {SKINS.filter((s) => s.id !== "default").map((s) => (
              <div
                key={s.id}
                className="overflow-hidden rounded-xl border border-border bg-surface"
              >
                <div className="relative aspect-[16/10] bg-surface-2">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={s.showcase}
                    alt={s.name}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute right-2 top-2 rounded-full bg-accent-2/90 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-bg">
                    Pro
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold">{s.name}</h3>
                    <span className="ml-auto flex gap-0.5">
                      {(["destroyer", "submarine", "cruiser", "battleship", "carrier"] as const).map(
                        (sid) => (
                          <span
                            key={sid}
                            className="grid size-6 place-items-center rounded border border-border bg-ship text-sm"
                          >
                            {s.icons[sid]}
                          </span>
                        ),
                      )}
                    </span>
                  </div>
                  <p className="mt-1.5 text-xs text-text-dim">{s.blurb}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 rounded-xl border border-border bg-surface p-6 text-center">
          <h3 className="font-bold">Want to preview the Academy now?</h3>
          <p className="mt-1 text-xs text-text-dim">
            The first chapter is free. The rest unlocks with the Pass.
          </p>
          <Link
            href="/academy"
            className="mt-3 inline-block rounded-md bg-accent px-5 py-2 text-sm font-bold text-white hover:opacity-90"
          >
            🏛 Visit the Naval Academy
          </Link>
        </div>
      </div>
    </main>
  );
}
