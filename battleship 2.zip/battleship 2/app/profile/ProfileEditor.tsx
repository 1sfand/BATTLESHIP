"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabaseBrowser } from "@/lib/supabase/client";
import type { ProfileRow } from "@/lib/supabase/types";
import { LeagueBadge } from "@/components/league/LeagueBadge";
import { getLeague, nextLeague, pointsToNextLeague } from "@/lib/league";

interface Props {
  profile: ProfileRow;
  email: string | null;
  isAnon: boolean;
}

export function ProfileEditor({ profile, email, isAnon }: Props) {
  const router = useRouter();
  const supabase = getSupabaseBrowser();
  const [nickname, setNickname] = useState(profile.nickname);
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url ?? "");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  if (!supabase) return null;

  const save = async () => {
    setSaving(true);
    setMsg(null);
    const trimmed = nickname.trim();
    if (trimmed.length < 2 || trimmed.length > 24) {
      setMsg({ kind: "err", text: "Nickname must be 2–24 characters." });
      setSaving(false);
      return;
    }
    const { error } = await supabase
      .from("profiles")
      .update({ nickname: trimmed, avatar_url: avatarUrl || null })
      .eq("id", profile.id);
    setSaving(false);
    if (error) {
      setMsg({ kind: "err", text: error.message });
    } else {
      setMsg({ kind: "ok", text: "Saved." });
      router.refresh();
    }
  };

  const league = getLeague(profile.rating);
  const next = nextLeague(profile.rating);
  const toNext = pointsToNextLeague(profile.rating);
  const lastThreshold = next ? league.threshold : 0;
  const progress = next
    ? Math.min(100, Math.round(((profile.rating - lastThreshold) / (next.threshold - lastThreshold)) * 100))
    : 100;

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-xl border border-border bg-surface p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
              Current league
            </p>
            <div className="mt-1">
              <LeagueBadge rating={profile.rating} size="md" showRating />
            </div>
          </div>
          {next && (
            <div className="text-right text-xs text-text-dim">
              <p>{toNext} ELO to</p>
              <p className="text-text">{next.symbol} {next.name}</p>
            </div>
          )}
        </div>
        {next && (
          <div className="h-2 w-full overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full bg-accent transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
        {!next && (
          <p className="text-xs text-cyan-300">💠 Top league reached. Defend the crown.</p>
        )}
        <p className="mt-2 text-[11px] italic text-text-dim">{league.motto}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Stat label="Wins" value={profile.wins} />
        <Stat label="Losses" value={profile.losses} />
        <Stat
          label="Accuracy"
          value={profile.shots > 0 ? `${Math.round((profile.hits / profile.shots) * 100)}%` : "—"}
        />
      </div>

      <div className="rounded-xl border border-border bg-surface p-5">
        <label className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-text-dim">
          Nickname
        </label>
        <input
          type="text"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          className="w-full rounded-md border border-border bg-surface-2 px-3 py-2 text-sm outline-none focus:border-accent"
          minLength={2}
          maxLength={24}
        />

        <label className="mt-4 mb-1 block text-[10px] font-bold uppercase tracking-widest text-text-dim">
          Avatar URL
        </label>
        <input
          type="url"
          placeholder="https://…/avatar.png"
          value={avatarUrl}
          onChange={(e) => setAvatarUrl(e.target.value)}
          className="w-full rounded-md border border-border bg-surface-2 px-3 py-2 text-sm outline-none focus:border-accent"
        />

        <div className="mt-4 flex items-center justify-between">
          <p className="text-xs text-text-dim">
            {email ? `Signed in as ${email}` : isAnon ? "Guest account" : "Linked account"}
          </p>
          <button
            onClick={save}
            disabled={saving}
            className="rounded-md bg-accent px-4 py-2 text-sm font-bold text-white hover:opacity-90 disabled:opacity-50"
          >
            {saving ? "Saving…" : "Save"}
          </button>
        </div>

        {msg && (
          <p className={`mt-2 text-xs ${msg.kind === "ok" ? "text-green" : "text-hit"}`}>
            {msg.text}
          </p>
        )}
      </div>

      {isAnon && (
        <div className="rounded-xl border border-accent-2/40 bg-accent-2/10 p-4 text-sm">
          <p className="font-bold text-accent-2">You&apos;re a guest</p>
          <p className="mt-1 text-text-dim">
            Sign in with Google or email to lock in your stats. Your progress
            transfers automatically.
          </p>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-lg border border-border bg-surface p-3">
      <div className="text-2xl font-black text-accent">{value}</div>
      <div className="text-[10px] uppercase tracking-widest text-text-dim">
        {label}
      </div>
    </div>
  );
}
