import Link from "next/link";
import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { ProfileEditor } from "./ProfileEditor";

export const metadata = { title: "Profile · Battleship" };

export default async function ProfilePage() {
  if (!isSupabaseConfigured()) return <NotConfigured />;

  const supabase = await getSupabaseServer();
  if (!supabase) return <NotConfigured />;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth/sign-in?next=/profile");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-6 py-12">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-md">
        <h1 className="title-gradient mb-1 text-3xl font-black uppercase tracking-wider">
          Profile
        </h1>
        <p className="mb-8 text-sm text-text-dim">
          Your nickname appears on leaderboards and replay shares.
        </p>

        {profile ? (
          <ProfileEditor profile={profile} email={user.email ?? null} isAnon={!!user.is_anonymous} />
        ) : (
          <div className="rounded-md border border-hit/40 bg-hit/10 p-4 text-sm text-hit">
            Profile not found. This usually self-heals on next sign-in.
          </div>
        )}
      </div>
    </main>
  );
}

function NotConfigured() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <div className="max-w-md rounded-2xl border border-border bg-surface p-8 text-center">
        <p className="text-text-dim">
          Cloud features aren&apos;t configured yet. Add Supabase env vars to enable profiles.
        </p>
        <Link href="/" className="mt-4 inline-block text-accent hover:underline">
          ← Back home
        </Link>
      </div>
    </main>
  );
}
