import Link from "next/link";
import { notFound } from "next/navigation";
import { getLesson } from "@/lib/academy/lessons";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";

interface Props { params: Promise<{ lesson: string }> }

export async function generateMetadata({ params }: Props) {
  const { lesson: id } = await params;
  const l = getLesson(id);
  return { title: l ? `${l.title} · Academy` : "Lesson · Battleship" };
}

export default async function LessonPage({ params }: Props) {
  const { lesson: id } = await params;
  const lesson = getLesson(id);
  if (!lesson) notFound();

  let isPro = false;
  if (isSupabaseConfigured()) {
    const supabase = await getSupabaseServer();
    if (supabase) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from("profiles")
          .select("is_pro")
          .eq("id", user.id)
          .maybeSingle();
        isPro = !!(data as { is_pro: boolean } | null)?.is_pro;
      }
    }
  }

  const locked = !lesson.free && !isPro;

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/academy" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Academy
      </Link>

      <article className="w-full max-w-2xl">
        <div className="mb-2 flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
          <span>{lesson.category}</span>
          <span>·</span>
          <span>{lesson.level}</span>
          <span>·</span>
          <span>{lesson.minutes} min</span>
          {lesson.free ? (
            <span className="rounded bg-green/20 px-1.5 py-0.5 text-green">Free</span>
          ) : (
            <span className="rounded bg-accent-2/20 px-1.5 py-0.5 text-accent-2">Admiral's Pass</span>
          )}
        </div>

        <h1 className="text-3xl font-black md:text-4xl">{lesson.title}</h1>
        <p className="mt-2 text-sm text-text-dim">{lesson.intro}</p>

        <div className="mt-8 rounded-xl border border-border bg-surface p-6">
          {locked ? (
            <LockedNotice />
          ) : (
            <div className="prose prose-invert max-w-none whitespace-pre-wrap text-sm leading-relaxed text-text">
              {lesson.body}
            </div>
          )}
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 text-xs">
          <Link href="/academy" className="text-text-dim hover:text-accent">← All lessons</Link>
          {!lesson.free && (
            <Link href="/upgrade" className="text-accent hover:underline">Get full access →</Link>
          )}
        </div>
      </article>
    </main>
  );
}

function LockedNotice() {
  return (
    <div className="text-center">
      <div className="text-5xl">🔒</div>
      <h2 className="mt-3 text-xl font-bold">This lesson is part of the Admiral's Pass</h2>
      <p className="mt-2 text-sm text-text-dim">
        Probability theory, historical campaigns, and engineering deep-dives.
        Subscribe once — own the curriculum forever (yearly + lifetime tiers).
      </p>
      <Link
        href="/upgrade"
        className="mt-4 inline-block rounded-md bg-accent-2 px-5 py-2.5 text-sm font-bold text-bg hover:opacity-90"
      >
        👑 See plans
      </Link>
    </div>
  );
}
