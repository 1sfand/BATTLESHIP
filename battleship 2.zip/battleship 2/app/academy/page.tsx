import Link from "next/link";
import { LESSONS } from "@/lib/academy/lessons";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";

export const metadata = { title: "Naval Academy · Battleship" };

export default async function AcademyIndexPage() {
  let isPro = false;
  if (isSupabaseConfigured()) {
    const supabase = await getSupabaseServer();
    if (supabase) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from("profiles")
          .select("is_pro")
          .eq("id", user.id)
          .maybeSingle();
        isPro = !!(data as { is_pro: boolean } | null)?.is_pro;
      }
    }
  }

  const grouped = {
    Strategy: LESSONS.filter((l) => l.category === "Strategy"),
    Probability: LESSONS.filter((l) => l.category === "Probability"),
    History: LESSONS.filter((l) => l.category === "History"),
    Engineering: LESSONS.filter((l) => l.category === "Engineering"),
  };

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-4xl">
        <div className="mb-2">
          <span className="rounded-full border border-accent-2 bg-accent-2/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-accent-2">
            🏛 Naval Academy
          </span>
        </div>
        <h1 className="title-gradient text-3xl font-black uppercase tracking-wider md:text-4xl">
          Learn the Game
        </h1>
        <p className="mt-2 max-w-xl text-sm text-text-dim">
          Lessons in strategy, probability, and history — written for players who want to
          actually understand why the Hard bot is so hard.
        </p>

        {!isPro && (
          <div className="mt-6 rounded-xl border border-accent-2/40 bg-accent-2/10 p-4 text-sm">
            <p className="font-bold text-accent-2">📖 First two lessons are free.</p>
            <p className="mt-1 text-text-dim">
              The full curriculum (probability, history, engineering) unlocks with{" "}
              <Link href="/upgrade" className="text-accent underline">Admiral's Pass</Link>.
            </p>
          </div>
        )}

        <div className="mt-8 flex flex-col gap-8">
          {Object.entries(grouped).map(([category, lessons]) => (
            <section key={category}>
              <h2 className="mb-3 text-[10px] font-bold uppercase tracking-widest text-text-dim">
                {category}
              </h2>
              <div className="grid gap-3 md:grid-cols-2">
                {lessons.map((l) => {
                  const locked = !l.free && !isPro;
                  return (
                    <Link
                      key={l.id}
                      href={`/academy/${l.id}`}
                      className={`flex gap-4 rounded-xl border p-5 transition ${
                        locked
                          ? "border-border bg-surface opacity-70 hover:opacity-100"
                          : "border-border bg-surface hover:border-accent"
                      }`}
                    >
                      <div className="text-3xl">{l.emoji}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
                          <span>{l.level}</span>
                          <span>·</span>
                          <span>{l.minutes} min</span>
                          {locked && (
                            <span className="rounded bg-accent-2/20 px-1.5 py-0.5 text-accent-2">
                              🔒 Pass
                            </span>
                          )}
                          {l.free && (
                            <span className="rounded bg-green/20 px-1.5 py-0.5 text-green">Free</span>
                          )}
                        </div>
                        <h3 className="mt-1 font-bold">{l.title}</h3>
                        <p className="mt-1 text-xs text-text-dim">{l.intro}</p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
