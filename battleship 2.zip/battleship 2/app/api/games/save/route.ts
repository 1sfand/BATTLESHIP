import { NextResponse, type NextRequest } from "next/server";
import { getSupabaseServer } from "@/lib/supabase/server";
import type { GameState } from "@/lib/engine";

/**
 * POST /api/games/save
 *
 * Body: { game: GameState }
 *
 * Saves a finished game record for the signed-in user, increments their
 * shot/hit counters, and applies ELO if both players are real users.
 */
export async function POST(req: NextRequest) {
  const supabase = await getSupabaseServer();
  if (!supabase) return NextResponse.json({ error: "not_configured" }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let body: { game?: GameState };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  const game = body.game;
  if (!game || game.phase !== "gameover" || game.winner === null) {
    return NextResponse.json({ error: "game_not_over" }, { status: 400 });
  }

  // Player 1 is always the signed-in human; player 2 is bot or unknown for now.
  // Online mode (later) will pass both player ids explicitly.
  const userIsWinner = game.winner === 0;
  const playerStats0 = game.stats[0];
  const playerStats1 = game.stats[1];

  // Snapshot initial ship placements for replay
  const initialState = {
    p0_ships: game.players[0].ships.map((s) => ({ id: s.id, positions: s.positions })),
    p1_ships: game.players[1].ships.map((s) => ({ id: s.id, positions: s.positions })),
  };

  const { data: gameRow, error: insertErr } = await supabase
    .from("games")
    .insert({
      mode: game.mode,
      difficulty: game.difficulty,
      story_chapter: game.storyChapter,
      player1_id: user.id,
      player2_id: null,                           // bot or local opponent
      winner_id: userIsWinner ? user.id : null,
      player1_stats: playerStats0,
      player2_stats: playerStats1,
      initial_state: initialState,
      moves: game.moves as unknown[],
      duration_seconds: game.endedAt && game.startedAt
        ? Math.round((game.endedAt - game.startedAt) / 1000)
        : null,
      ended_at: game.endedAt ? new Date(game.endedAt).toISOString() : null,
      is_public: true,
    })
    .select("id")
    .single();

  if (insertErr) {
    return NextResponse.json({ error: insertErr.message }, { status: 500 });
  }

  // Bump counters: shots/hits regardless of mode; wins/losses only for ranked.
  const ranked = game.mode === "bot" || game.mode === "online"; // adjust as desired
  const profileUpdate: Record<string, unknown> = {};

  // Cumulative shots/hits via .rpc would be cleaner; we read-modify-write here.
  const { data: profile } = await supabase
    .from("profiles")
    .select("shots, hits, wins, losses, rating")
    .eq("id", user.id)
    .maybeSingle();

  if (profile) {
    profileUpdate.shots = profile.shots + playerStats0.shots;
    profileUpdate.hits = profile.hits + playerStats0.hits;
    if (ranked) {
      if (userIsWinner) profileUpdate.wins = profile.wins + 1;
      else profileUpdate.losses = profile.losses + 1;

      // Bot ELO baseline depends on difficulty (rough heuristic)
      const botRating =
        game.difficulty === "hard" ? 1500 :
        game.difficulty === "medium" ? 1300 : 1100;
      const expected = 1 / (1 + Math.pow(10, (botRating - profile.rating) / 400));
      const score = userIsWinner ? 1 : 0;
      const delta = Math.round(32 * (score - expected));
      profileUpdate.rating = Math.max(0, profile.rating + delta);
    }

    await supabase.from("profiles").update(profileUpdate).eq("id", user.id);
  }

  return NextResponse.json({ id: gameRow.id });
}
