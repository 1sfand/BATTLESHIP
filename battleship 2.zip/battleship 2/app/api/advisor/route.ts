import { NextResponse, type NextRequest } from "next/server";
import { getSupabaseServer } from "@/lib/supabase/server";
import { createReplay, type ReplayInitial } from "@/lib/replay/reconstruct";
import { COLS } from "@/lib/engine";
import type { Move } from "@/lib/engine";
import type { GameRow } from "@/lib/supabase/types";
import { getAdvisorProvider } from "@/lib/ai/advisor-llm";

export const runtime = "nodejs";

/**
 * POST /api/advisor
 *
 * Body: { gameId: string, moveIndex: number }
 *
 * Streams the configured LLM's commentary on the move at `moveIndex`. Caches
 * the result in games.advisor_commentary[moveIndex] so repeat views are free.
 *
 * Falls back gracefully:
 *   - 503 if no LLM provider key (GOOGLE_GENAI_API_KEY or ANTHROPIC_API_KEY)
 *   - 503 if Supabase isn't configured
 */
export async function POST(req: NextRequest) {
  const provider = getAdvisorProvider();
  if (!provider) {
    return NextResponse.json({ error: "advisor_not_configured" }, { status: 503 });
  }

  const supabase = await getSupabaseServer();
  if (!supabase) {
    return NextResponse.json({ error: "db_not_configured" }, { status: 503 });
  }

  let body: { gameId?: string; moveIndex?: number };
  try { body = await req.json(); } catch { return NextResponse.json({ error: "bad_json" }, { status: 400 }); }
  const { gameId, moveIndex } = body;
  if (!gameId || typeof moveIndex !== "number") {
    return NextResponse.json({ error: "missing_params" }, { status: 400 });
  }

  // Fetch game
  const result = await supabase
    .from("games")
    .select("*")
    .eq("id", gameId)
    .maybeSingle();
  const game = result.data as GameRow | null;
  if (!game) return NextResponse.json({ error: "not_found" }, { status: 404 });

  // Cached?
  const cache = (game.advisor_commentary ?? {}) as Record<string, string>;
  const cached = cache[String(moveIndex)];
  if (cached) {
    return new Response(cached, {
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  // Reconstruct context for the model
  const initial = game.initial_state as unknown as ReplayInitial;
  const moves = (game.moves as unknown as Move[]) ?? [];
  if (moveIndex < 0 || moveIndex >= moves.length) {
    return NextResponse.json({ error: "invalid_move_index" }, { status: 400 });
  }

  const replay = createReplay(initial, moves);
  const after = replay.snapshotAt(moveIndex);
  const move = moves[moveIndex];

  const attackerLabel = move.attacker === 0 ? "Player 1" : "Player 2";
  const defenderShips = after.ships[move.attacker ^ 1];
  const remainingSizes = defenderShips.filter((s) => !s.sunk).map((s) => s.size).sort((a, b) => b - a);
  const sunkNames = defenderShips.filter((s) => s.sunk).map((s) => s.name);

  // Surrounding context
  const defenderBoard = after.boards[move.attacker ^ 1];
  let totalShots = 0;
  let totalHits = 0;
  for (const row of defenderBoard) for (const c of row) {
    if (c.hit) {
      totalShots++;
      if (c.shipId) totalHits++;
    }
  }

  const prompt = `You are a witty, concise naval-strategy advisor commenting on a Battleship replay.

The game is between ${game.mode === "bot" ? `a human (Player 1) and a ${game.difficulty} bot (Player 2)` : "two players"}.

Move #${moveIndex + 1} of ${moves.length}: ${attackerLabel} fires at ${COLS[move.col]}${move.row + 1}.
Result: ${move.hit ? (move.sunkShipId ? `SUNK ${move.sunkShipId}!` : "HIT") : "miss"}.

State after this shot (from ${attackerLabel}'s perspective):
- Total shots fired by ${attackerLabel}: ${totalShots}
- Hits: ${totalHits} (accuracy ${totalShots > 0 ? Math.round((totalHits / totalShots) * 100) : 0}%)
- Enemy ships remaining: ${remainingSizes.length} (sizes ${remainingSizes.join(", ") || "none"})
- Enemy ships sunk: ${sunkNames.join(", ") || "none yet"}

Write 1–2 short sentences (max 30 words) commenting on this move with a naval/tactical voice. Be specific to the move and state — call out smart targeting, missed opportunities, or dramatic moments. No preamble, no quotes, no "—". Just the commentary.`;

  // Stream chunks back to the client and accumulate for cache write at end.
  const encoder = new TextEncoder();
  let full = "";

  const readable = new ReadableStream({
    async start(controller) {
      try {
        for await (const text of provider.stream({ prompt, maxTokens: 120 })) {
          full += text;
          controller.enqueue(encoder.encode(text));
        }
      } catch (e) {
        controller.enqueue(encoder.encode(`(advisor error: ${(e as Error).message})`));
      } finally {
        controller.close();
        if (full) {
          await supabase
            .from("games")
            .update({
              advisor_commentary: { ...cache, [String(moveIndex)]: full },
            })
            .eq("id", gameId);
        }
      }
    },
  });

  return new Response(readable, {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}
