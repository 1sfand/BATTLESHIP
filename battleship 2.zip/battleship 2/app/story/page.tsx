import Link from "next/link";
import { CHAPTERS } from "@/lib/story/chapters";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import type { StoryProgressRow } from "@/lib/supabase/types";

export const metadata = { title: "Story Mode · Battleship" };

export default async function StoryIndexPage() {
  let progress: StoryProgressRow | null = null;
  if (isSupabaseConfigured()) {
    const supabase = await getSupabaseServer();
    if (supabase) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from("story_progress")
          .select("*")
          .eq("user_id", user.id)
          .maybeSingle();
        progress = (data as StoryProgressRow | null) ?? null;
      }
    }
  }

  const completed = new Set(progress?.completed_chapters ?? []);
  const current = progress?.current_chapter ?? 1;

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-2xl">
        <h1 className="title-gradient mb-1 text-3xl font-black uppercase tracking-wider">
          📜 Story Mode
        </h1>
        <p className="mb-8 text-sm text-text-dim">
          Defeat the admirals. Each victory unlocks a reward.
        </p>

        <ol className="flex flex-col gap-3">
          {CHAPTERS.map((c) => {
            const isCompleted = completed.has(c.id);
            const isCurrent = c.id === current && !isCompleted;
            const isLocked = c.id > current && !isCompleted;
            return (
              <li
                key={c.id}
                className={`rounded-xl border p-5 transition ${
                  isLocked
                    ? "border-border bg-surface opacity-50"
                    : isCurrent
                      ? "border-accent bg-surface hover:bg-surface-2"
                      : "border-border bg-surface hover:border-accent"
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="text-3xl">{c.portrait}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
                        Ch. {c.id} · {c.difficulty}
                      </span>
                      {isCompleted && (
                        <span className="rounded bg-green/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-green">
                          ✓ Cleared
                        </span>
                      )}
                      {isCurrent && (
                        <span className="rounded bg-accent/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-accent">
                          Current
                        </span>
                      )}
                      {isLocked && (
                        <span className="rounded bg-border-2/40 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-text-dim">
                          🔒 Locked
                        </span>
                      )}
                    </div>
                    <h2 className="mt-1 text-lg font-bold">{c.title}</h2>
                    <p className="text-xs text-text-dim">vs {c.admiral}</p>
                    {c.reward && (
                      <p className="mt-1 text-xs text-accent-2">Reward: {c.reward.label}</p>
                    )}
                  </div>
                  {!isLocked && (
                    <Link
                      href={`/story/${c.id}`}
                      className="rounded-md bg-accent px-4 py-2 text-xs font-bold text-white hover:opacity-90"
                    >
                      {isCompleted ? "Replay" : "Engage"}
                    </Link>
                  )}
                </div>
              </li>
            );
          })}
        </ol>

        {!isSupabaseConfigured() && (
          <p className="mt-6 text-xs text-text-dim">
            Sign in to save your story progress across devices.
          </p>
        )}
      </div>
    </main>
  );
}
