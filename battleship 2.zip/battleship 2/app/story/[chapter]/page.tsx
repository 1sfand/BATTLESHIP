import Link from "next/link";
import { notFound } from "next/navigation";
import { getChapter } from "@/lib/story/chapters";
import { StoryChapterRunner } from "./StoryChapterRunner";

export const metadata = { title: "Story Chapter · Battleship" };

interface Props { params: Promise<{ chapter: string }> }

export default async function StoryChapterPage({ params }: Props) {
  const { chapter } = await params;
  const id = Number(chapter);
  if (!Number.isFinite(id)) notFound();
  const ch = getChapter(id);
  if (!ch) notFound();

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-8">
      <Link href="/story" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Story
      </Link>
      <StoryChapterRunner chapter={ch} />
    </main>
  );
}
