"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import type { Chapter } from "@/lib/story/chapters";
import { useGameStore } from "@/stores/game";
import { useThemeStore } from "@/stores/theme";
import { GameView } from "@/components/game/GameView";
import { getSupabaseBrowser } from "@/lib/supabase/client";

type Stage = "intro" | "battle" | "outro";

export function StoryChapterRunner({ chapter }: { chapter: Chapter }) {
  const [stage, setStage] = useState<Stage>("intro");
  const [lineIdx, setLineIdx] = useState(0);
  const startBotGame = useGameStore((s) => s.startBotGame);
  const reset = useGameStore((s) => s.reset);
  const game = useGameStore((s) => s.game);
  const unlock = useThemeStore((s) => s.unlock);

  const intro = chapter.intro;
  const won = game?.phase === "gameover" && game.winner === 0;
  const lost = game?.phase === "gameover" && game.winner === 1;

  // Transition to outro when game ends
  useEffect(() => {
    if (stage === "battle" && (won || lost)) setStage("outro");
  }, [stage, won, lost]);

  const startBattle = () => {
    reset();
    startBotGame(chapter.difficulty);
    setStage("battle");
  };

  // On win, persist story_progress server-side + grant theme unlock locally
  useEffect(() => {
    if (stage !== "outro" || !won) return;
    if (chapter.reward?.type === "theme") unlock(chapter.reward.id as never);
    void persistChapterCompletion(chapter.id);
  }, [stage, won, chapter, unlock]);

  if (stage === "intro") {
    const line = intro[lineIdx];
    const last = lineIdx >= intro.length - 1;
    return (
      <DialoguePanel
        chapter={chapter}
        speakerLabel={line.who === "admiral" ? chapter.admiral : line.who === "you" ? "You" : "Narrator"}
        portrait={line.who === "admiral" ? chapter.portrait : line.who === "you" ? "👤" : "🌊"}
        text={line.text}
        primaryLabel={last ? "⚔ Engage" : "Next →"}
        onPrimary={() => last ? startBattle() : setLineIdx(lineIdx + 1)}
      />
    );
  }

  if (stage === "battle") {
    return <GameView mode="bot" />;
  }

  // outro
  const lines = won ? chapter.outroWin : chapter.outroLose;
  const line = lines[lineIdx] ?? lines[lines.length - 1];
  const last = lineIdx >= lines.length - 1;
  return (
    <DialoguePanel
      chapter={chapter}
      speakerLabel={line.who === "admiral" ? chapter.admiral : line.who === "you" ? "You" : "Narrator"}
      portrait={line.who === "admiral" ? chapter.portrait : line.who === "you" ? "👤" : "🌊"}
      text={line.text}
      primaryLabel={last ? (won ? "Claim Reward →" : "Try Again") : "Next →"}
      onPrimary={() => {
        if (!last) { setLineIdx(lineIdx + 1); return; }
        if (won) { window.location.href = "/story"; }
        else { setLineIdx(0); setStage("intro"); reset(); }
      }}
      meta={
        last && won && chapter.reward ? (
          <p className="mt-3 text-sm text-accent-2">🎁 Unlocked: {chapter.reward.label}</p>
        ) : null
      }
    />
  );
}

function DialoguePanel({
  chapter,
  speakerLabel,
  portrait,
  text,
  primaryLabel,
  onPrimary,
  meta,
}: {
  chapter: Chapter;
  speakerLabel: string;
  portrait: string;
  text: string;
  primaryLabel: string;
  onPrimary: () => void;
  meta?: React.ReactNode;
}) {
  return (
    <div className="flex w-full max-w-xl flex-col items-center gap-4 animate-fade-in-up">
      <div className="text-center">
        <p className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
          Chapter {chapter.id} · {chapter.title}
        </p>
      </div>
      <div className="flex w-full items-start gap-4 rounded-2xl border border-border bg-surface p-6">
        <span className="text-5xl">{portrait}</span>
        <div className="flex-1">
          <p className="mb-1 text-[10px] font-bold uppercase tracking-widest text-accent">
            {speakerLabel}
          </p>
          <p className="text-base leading-relaxed">{text}</p>
          {meta}
        </div>
      </div>
      <button
        onClick={onPrimary}
        className="rounded-md bg-accent px-6 py-3 text-sm font-bold text-white hover:opacity-90"
      >
        {primaryLabel}
      </button>
      <Link href="/story" className="text-xs text-text-dim hover:text-accent">
        Leave chapter
      </Link>
    </div>
  );
}

async function persistChapterCompletion(chapterId: number) {
  const supabase = getSupabaseBrowser();
  if (!supabase) return;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const { data: existing } = await supabase
    .from("story_progress")
    .select("*")
    .eq("user_id", user.id)
    .maybeSingle();

  type Existing = { current_chapter: number; completed_chapters: number[]; unlocks: { themes?: string[] } };
  const e = existing as Existing | null;
  const completed = new Set(e?.completed_chapters ?? []);
  completed.add(chapterId);
  const nextChapter = Math.max(e?.current_chapter ?? 1, chapterId + 1);

  await supabase.from("story_progress").upsert({
    user_id: user.id,
    current_chapter: nextChapter,
    completed_chapters: Array.from(completed).sort((a, b) => a - b),
    unlocks: e?.unlocks ?? {},
  });
}
