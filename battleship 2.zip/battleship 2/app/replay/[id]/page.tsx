import Link from "next/link";
import { notFound } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { ReplayViewer } from "./ReplayViewer";
import type { ReplayInitial } from "@/lib/replay/reconstruct";
import type { Move } from "@/lib/engine";

export const metadata = { title: "Replay · Battleship" };

interface PageProps {
  params: Promise<{ id: string }>;
}

export default async function ReplayPage({ params }: PageProps) {
  const { id } = await params;

  if (!isSupabaseConfigured()) return <NotConfigured />;

  const supabase = await getSupabaseServer();
  if (!supabase) return <NotConfigured />;

  const { data: game } = await supabase
    .from("games")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (!game) notFound();

  const initial = game.initial_state as unknown as ReplayInitial;
  const moves = (game.moves as unknown as Move[]) ?? [];

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-8">
      <Link href="/stats" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Back
      </Link>

      <div className="mb-4 text-center">
        <h1 className="title-gradient text-2xl font-black uppercase tracking-wider">
          Replay
        </h1>
        <p className="text-xs uppercase tracking-widest text-text-dim">
          {game.mode}
          {game.difficulty && ` · ${game.difficulty}`}
          {" · "}
          {moves.length} moves
        </p>
      </div>

      <ReplayViewer
        gameId={game.id}
        initial={initial}
        moves={moves}
        winner={game.winner_id}
      />
    </main>
  );
}

function NotConfigured() {
  return (
    <main className="flex flex-1 items-center justify-center p-8">
      <p className="text-text-dim">Replays require cloud setup.</p>
    </main>
  );
}
