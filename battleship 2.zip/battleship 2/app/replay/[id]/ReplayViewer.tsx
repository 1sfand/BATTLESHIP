"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Board } from "@/components/game/Board";
import { FleetStatus } from "@/components/game/FleetStatus";
import { createReplay, type ReplayInitial } from "@/lib/replay/reconstruct";
import type { Move } from "@/lib/engine";
import { COLS } from "@/lib/engine";
import { cn } from "@/lib/utils/cn";

interface Props {
  gameId: string;
  initial: ReplayInitial;
  moves: Move[];
  winner: string | null;
}

export function ReplayViewer({ gameId, initial, moves, winner }: Props) {
  const replay = useMemo(() => createReplay(initial, moves), [initial, moves]);
  const [idx, setIdx] = useState(-1); // -1 = before first move
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState<1 | 2 | 4>(2);
  const [advisor, setAdvisor] = useState<string>("");
  const [advisorLoading, setAdvisorLoading] = useState(false);
  const advisorAbort = useRef<AbortController | null>(null);

  const snapshot = useMemo(() => replay.snapshotAt(idx), [replay, idx]);
  const total = replay.totalMoves;

  // Auto-play
  useEffect(() => {
    if (!playing) return;
    if (idx >= total - 1) { setPlaying(false); return; }
    const ms = 700 / speed;
    const t = setTimeout(() => setIdx((i) => Math.min(i + 1, total - 1)), ms);
    return () => clearTimeout(t);
  }, [playing, idx, total, speed]);

  // Stream advisor commentary for current move
  useEffect(() => {
    if (idx < 0 || idx >= total) return;
    advisorAbort.current?.abort();
    const ac = new AbortController();
    advisorAbort.current = ac;
    setAdvisor("");
    setAdvisorLoading(true);

    fetch("/api/advisor", {
      method: "POST",
      signal: ac.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gameId, moveIndex: idx }),
    })
      .then(async (r) => {
        if (!r.ok || !r.body) {
          if (r.status === 503) setAdvisor("(AI advisor offline — set ANTHROPIC_API_KEY to enable)");
          setAdvisorLoading(false);
          return;
        }
        const reader = r.body.getReader();
        const decoder = new TextDecoder();
        // eslint-disable-next-line no-constant-condition
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          setAdvisor((prev) => prev + decoder.decode(value));
        }
        setAdvisorLoading(false);
      })
      .catch(() => setAdvisorLoading(false));

    return () => ac.abort();
  }, [idx, gameId, total]);

  const move = idx >= 0 ? moves[idx] : null;
  const moveLabel = move
    ? `${move.attacker === 0 ? "P1" : "P2"} → ${COLS[move.col]}${move.row + 1} ${move.hit ? (move.sunkShipId ? "💥 SUNK" : "🎯 HIT") : "💧 miss"}`
    : "Initial setup";

  return (
    <div className="flex w-full max-w-5xl flex-col items-center gap-5">
      <div className="flex flex-wrap items-start justify-center gap-8">
        <BoardSection
          title="Player 1"
          board={snapshot.boards[0]}
          ships={snapshot.ships[0]}
          highlight={move?.attacker === 1 ? [move.row, move.col] : null}
        />
        <BoardSection
          title="Player 2"
          board={snapshot.boards[1]}
          ships={snapshot.ships[1]}
          highlight={move?.attacker === 0 ? [move.row, move.col] : null}
        />
      </div>

      {/* Advisor pane */}
      <div className="w-full max-w-2xl rounded-xl border border-accent/30 bg-surface p-4">
        <div className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-accent">
          🧭 AI Advisor {advisorLoading && <span className="animate-pulse text-text-dim">· thinking…</span>}
        </div>
        <p className="min-h-[2.5em] whitespace-pre-wrap text-sm leading-relaxed text-text-dim">
          {advisor || (idx < 0 ? "Press play to start the replay." : moveLabel)}
        </p>
      </div>

      {/* Scrubber */}
      <div className="w-full max-w-2xl rounded-xl border border-border bg-surface p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs text-text-dim">
            Move <strong className="text-text">{Math.max(0, idx + 1)}</strong> / {total}
          </span>
          <span className="text-xs text-text-dim">{moveLabel}</span>
        </div>
        <input
          type="range"
          min={-1}
          max={total - 1}
          value={idx}
          onChange={(e) => { setPlaying(false); setIdx(Number(e.target.value)); }}
          className="w-full accent-accent"
        />
        <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => { setIdx(-1); setPlaying(false); }}
            className="rounded-md border border-border bg-surface-2 px-3 py-1.5 text-xs hover:border-accent"
          >
            ⏮ Restart
          </button>
          <button
            onClick={() => setIdx((i) => Math.max(-1, i - 1))}
            className="rounded-md border border-border bg-surface-2 px-3 py-1.5 text-xs hover:border-accent"
          >
            ◀ Prev
          </button>
          <button
            onClick={() => setPlaying((p) => !p)}
            className="rounded-md bg-accent px-4 py-1.5 text-xs font-bold text-white hover:opacity-90"
          >
            {playing ? "⏸ Pause" : "▶ Play"}
          </button>
          <button
            onClick={() => setIdx((i) => Math.min(total - 1, i + 1))}
            className="rounded-md border border-border bg-surface-2 px-3 py-1.5 text-xs hover:border-accent"
          >
            Next ▶
          </button>
          <button
            onClick={() => { setIdx(total - 1); setPlaying(false); }}
            className="rounded-md border border-border bg-surface-2 px-3 py-1.5 text-xs hover:border-accent"
          >
            ⏭ End
          </button>
          <div className="ml-2 flex gap-1">
            {[1, 2, 4].map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s as 1 | 2 | 4)}
                className={cn(
                  "rounded px-2 py-1 text-[10px] font-bold",
                  speed === s ? "bg-accent text-white" : "bg-surface-2 text-text-dim",
                )}
              >
                {s}×
              </button>
            ))}
          </div>
        </div>
      </div>

      {idx >= total - 1 && (
        <div className="text-sm text-accent-2">
          🏆 Winner: {winner ? "Player 1" : "Player 2"}
        </div>
      )}
    </div>
  );
}

function BoardSection({
  title,
  board,
  ships,
  highlight,
}: {
  title: string;
  board: import("@/lib/engine").Board;
  ships: import("@/lib/engine").PlacedShip[];
  highlight: [number, number] | null;
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="text-[10px] font-bold uppercase tracking-widest text-text-dim">
        {title}
        {highlight && (
          <span className="ml-2 text-accent-2">
            ← under fire {COLS[highlight[1]]}{highlight[0] + 1}
          </span>
        )}
      </div>
      <Board board={board} ships={ships} mode="own" />
      <FleetStatus ships={ships} board={board} />
    </div>
  );
}
