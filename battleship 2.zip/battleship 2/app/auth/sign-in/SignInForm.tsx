"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabaseBrowser } from "@/lib/supabase/client";

type Mode = "menu" | "email" | "loading";

export function SignInForm() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("menu");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  const supabase = getSupabaseBrowser();
  if (!supabase) return null;

  const siteUrl =
    process.env.NEXT_PUBLIC_SITE_URL ??
    (typeof window !== "undefined" ? window.location.origin : "");

  const signInWithGoogle = async () => {
    setMode("loading");
    setError(null);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${siteUrl}/auth/callback` },
    });
    if (error) {
      setError(error.message);
      setMode("menu");
    }
  };

  const signInWithEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setMode("loading");
    setError(null);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${siteUrl}/auth/callback` },
    });
    if (error) {
      setError(error.message);
      setMode("email");
    } else {
      setSent(true);
      setMode("email");
    }
  };

  const continueAsGuest = async () => {
    setMode("loading");
    setError(null);
    const { error } = await supabase.auth.signInAnonymously();
    if (error) {
      setError(error.message);
      setMode("menu");
    } else {
      router.push("/");
      router.refresh();
    }
  };

  if (sent) {
    return (
      <div className="rounded-md border border-green/40 bg-green/10 p-4 text-sm">
        <p className="font-bold text-green">Check your email</p>
        <p className="mt-1 text-text-dim">
          We sent a magic sign-in link to <strong>{email}</strong>.
        </p>
      </div>
    );
  }

  if (mode === "email") {
    return (
      <form onSubmit={signInWithEmail} className="flex flex-col gap-3">
        <input
          type="email"
          required
          autoFocus
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="rounded-md border border-border bg-surface-2 px-3 py-2 text-sm outline-none focus:border-accent"
        />
        <button
          type="submit"
          className="rounded-md bg-accent px-4 py-2 text-sm font-bold text-white hover:opacity-90"
        >
          Send magic link
        </button>
        <button
          type="button"
          onClick={() => setMode("menu")}
          className="text-xs text-text-dim hover:text-accent"
        >
          ← Back
        </button>
        {error && <p className="text-xs text-hit">{error}</p>}
      </form>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <button
        onClick={signInWithGoogle}
        disabled={mode === "loading"}
        className="flex items-center justify-center gap-2 rounded-md border border-border bg-surface-2 px-4 py-2.5 text-sm font-medium hover:border-accent disabled:opacity-50"
      >
        <span aria-hidden>🔵</span> Continue with Google
      </button>
      <button
        onClick={() => setMode("email")}
        disabled={mode === "loading"}
        className="rounded-md border border-border bg-surface-2 px-4 py-2.5 text-sm font-medium hover:border-accent disabled:opacity-50"
      >
        ✉ Continue with email
      </button>
      <div className="my-1 flex items-center gap-2 text-[10px] uppercase tracking-widest text-text-dim">
        <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
      </div>
      <button
        onClick={continueAsGuest}
        disabled={mode === "loading"}
        className="rounded-md bg-accent/10 px-4 py-2.5 text-sm font-medium text-accent hover:bg-accent/20 disabled:opacity-50"
      >
        Play as guest
      </button>
      <p className="mt-2 text-[11px] text-text-dim">
        Guest accounts can be upgraded later — you won&apos;t lose progress.
      </p>
      {error && <p className="text-xs text-hit">{error}</p>}
    </div>
  );
}
