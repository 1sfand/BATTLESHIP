import Link from "next/link";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { SignInForm } from "./SignInForm";

export const metadata = { title: "Sign in · Battleship" };

export default function SignInPage() {
  const configured = isSupabaseConfigured();

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>

      <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-8">
        <h1 className="mb-1 text-2xl font-bold">Sign in</h1>
        <p className="mb-6 text-sm text-text-dim">
          Save your progress, climb the leaderboard, unlock themes.
        </p>

        {configured ? (
          <SignInForm />
        ) : (
          <NotConfiguredNotice />
        )}
      </div>
    </main>
  );
}

function NotConfiguredNotice() {
  return (
    <div className="rounded-md border border-accent-2/40 bg-accent-2/10 p-4 text-sm">
      <p className="mb-2 font-bold text-accent-2">Auth not configured yet</p>
      <p className="text-text-dim">
        Add <code className="rounded bg-surface-2 px-1 text-xs">NEXT_PUBLIC_SUPABASE_URL</code> and{" "}
        <code className="rounded bg-surface-2 px-1 text-xs">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> to{" "}
        <code className="rounded bg-surface-2 px-1 text-xs">.env.local</code>, then restart the dev server.
      </p>
      <p className="mt-3 text-text-dim">
        Until then, you can still play offline as a guest.{" "}
        <Link href="/" className="text-accent hover:underline">Back to play</Link>.
      </p>
    </div>
  );
}
