import Link from "next/link";
import { getSupabaseServer } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/env";
import { LeagueBadge } from "@/components/league/LeagueBadge";
import { LEAGUES, getLeague } from "@/lib/league";

export const metadata = { title: "Leaderboard · Battleship" };
export const revalidate = 60; // cache 1 min

interface LeaderboardPageProps {
  searchParams: Promise<{ league?: string }>;
}

export default async function LeaderboardPage({ searchParams }: LeaderboardPageProps) {
  if (!isSupabaseConfigured()) {
    return <NotConfigured />;
  }

  const { league: leagueFilter } = await searchParams;
  const supabase = await getSupabaseServer();
  const { data: rows, error } = (await supabase
    ?.from("leaderboard")
    .select("*")
    .limit(100)) ?? { data: [], error: null };

  // Filter by league if a `?league=gold` etc query is present
  type Row = { id: string; nickname: string; avatar_url: string | null; rating: number; wins: number; losses: number; win_pct: number };
  const filtered = (rows as Row[] | null)?.filter((r) =>
    leagueFilter ? getLeague(r.rating).id === leagueFilter : true,
  ) ?? [];

  return (
    <main className="relative z-10 flex flex-1 flex-col items-center px-4 py-10">
      <Link href="/" className="absolute left-6 top-6 text-sm text-text-dim hover:text-accent">
        ← Home
      </Link>
      <div className="w-full max-w-3xl">
        <h1 className="title-gradient mb-1 text-3xl font-black uppercase tracking-wider">
          🏆 Leaderboard
        </h1>
        <p className="mb-6 text-sm text-text-dim">Top 100 admirals by ELO rating.</p>

        <div className="mb-6 flex flex-wrap gap-2">
          <Link
            href="/leaderboard"
            className={`rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-wider transition ${
              !leagueFilter ? "border-accent bg-accent text-white" : "border-border bg-surface text-text-dim hover:border-accent"
            }`}
          >
            All
          </Link>
          {LEAGUES.map((l) => (
            <Link
              key={l.id}
              href={`/leaderboard?league=${l.id}`}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-wider transition ${
                leagueFilter === l.id ? l.badge : "border-border bg-surface text-text-dim hover:border-accent"
              }`}
            >
              <span>{l.symbol}</span>
              <span>{l.name}</span>
            </Link>
          ))}
        </div>

        {error && (
          <p className="text-sm text-hit">Failed to load leaderboard: {error.message}</p>
        )}

        {filtered.length === 0 && (
          <p className="rounded-xl border border-border bg-surface p-8 text-center text-text-dim">
            No admirals here yet. Be the first to climb to {leagueFilter ? leagueFilter : "the top"}.
          </p>
        )}

        {filtered.length > 0 && (
          <ol className="overflow-hidden rounded-xl border border-border bg-surface">
            <li className="grid grid-cols-[40px_1fr_100px_60px_60px_60px] items-center gap-3 border-b border-border bg-surface-2 px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-text-dim">
              <span>#</span><span>Admiral</span><span>League</span>
              <span className="text-right">ELO</span>
              <span className="text-right">W/L</span><span className="text-right">Win %</span>
            </li>
            {filtered.map((r, i) => (
              <li
                key={r.id}
                className="grid grid-cols-[40px_1fr_100px_60px_60px_60px] items-center gap-3 border-b border-border px-4 py-3 text-sm last:border-b-0"
              >
                <span className={i < 3 ? "font-black text-accent-2" : "text-text-dim"}>{i + 1}</span>
                <span className="flex items-center gap-2 truncate">
                  {r.avatar_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={r.avatar_url} alt="" className="size-6 rounded-full" />
                  ) : (
                    <span className="grid size-6 place-items-center rounded-full bg-accent text-[10px] font-black text-white">
                      {r.nickname[0]?.toUpperCase()}
                    </span>
                  )}
                  <span className="truncate font-medium">{r.nickname}</span>
                </span>
                <LeagueBadge rating={r.rating} size="xs" />
                <span className="text-right font-black">{r.rating}</span>
                <span className="text-right text-xs text-text-dim">{r.wins}/{r.losses}</span>
                <span className="text-right text-xs">{r.win_pct}%</span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </main>
  );
}

function NotConfigured() {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
      <div className="max-w-md rounded-2xl border border-border bg-surface p-8 text-center">
        <p className="text-text-dim">
          Cloud features aren&apos;t configured. Set up Supabase to see global rankings.
        </p>
        <Link href="/" className="mt-4 inline-block text-accent hover:underline">← Back home</Link>
      </div>
    </main>
  );
}
